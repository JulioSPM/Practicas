﻿using System;
using System.Runtime.InteropServices;
using SAPbouiCOM;
using WinForms = System.Windows.Forms;

namespace AddonSPMClientes
{
    internal static class Program
    {
        private static SAPbouiCOM.Application SBO_Application;
        private static SAPbouiCOM.SboGuiApi SboGuiApi;

        // Formulario estándar de SAP B1:
        // Datos maestros de socio de negocios
        private const string FormTypeSocioNegocios = "134";

        // Pane personalizado para nuestra pestaña
        private const int PaneSpm = 99;

        // IDs personalizados
        private const string FolderSpm = "fldSPM";
        private const string UdsCodigoSpm = "UDSCOD";
        private const string UdsNombreSpm = "UDSNOM";

        private const string ItemLblCodigo = "lblCodS";
        private const string ItemTxtCodigo = "txtCodS";
        private const string ItemLblNombre = "lblNomS";
        private const string ItemTxtNombre = "txtNomS";
        private const string ItemBtnCrear = "btnCrS";

        [STAThread]
        private static void Main(string[] args)
        {
            try
            {
                ConectarConSap(args);
                RegistrarEventos();

                SBO_Application.StatusBar.SetText(
                    "Add-On SPM Clientes conectado correctamente.",
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Success
                );

                WinForms.Application.Run();
            }
            catch (Exception ex)
            {
                try
                {
                    if (SBO_Application != null)
                    {
                        SBO_Application.MessageBox("Error inicializando Add-On:\n" + ex.Message);
                    }
                    else
                    {
                        WinForms.MessageBox.Show(ex.ToString(), "Error Add-On SPM");
                    }
                }
                catch
                {
                    WinForms.MessageBox.Show(ex.ToString(), "Error Add-On SPM");
                }
            }
        }

        private static void ConectarConSap(string[] args)
        {
            if (args == null || args.Length == 0 || string.IsNullOrWhiteSpace(args[0]))
            {
                throw new Exception("No llegó el connection string de SAP.");
            }

            SboGuiApi = new SAPbouiCOM.SboGuiApi();
            SboGuiApi.Connect(args[0]);
            SBO_Application = SboGuiApi.GetApplication(-1);
        }

        private static void RegistrarEventos()
        {
            SBO_Application.ItemEvent += SBO_Application_ItemEvent;
            SBO_Application.AppEvent += SBO_Application_AppEvent;
        }

        private static void SBO_Application_ItemEvent(
            string FormUID,
            ref SAPbouiCOM.ItemEvent pVal,
            out bool BubbleEvent
        )
        {
            BubbleEvent = true;

            try
            {
                if (pVal.BeforeAction)
                    return;

                // Cuando abre el formulario de Socios de Negocio
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_FORM_LOAD)
                {
                    AgregarPestanaSpmSocioNegocios(FormUID);
                    return;
                }

                // Cuando presiona la pestaña SPM
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_ITEM_PRESSED &&
                    pVal.ItemUID == FolderSpm)
                {
                    SAPbouiCOM.Form form = SBO_Application.Forms.Item(FormUID);
                    form.PaneLevel = PaneSpm;
                    return;
                }

                // Cuando presiona el botón Crear cliente
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_ITEM_PRESSED &&
                    pVal.ItemUID == ItemBtnCrear)
                {
                    CrearClienteDesdeSpm(FormUID);
                    return;
                }
            }
            catch (Exception ex)
            {
                SBO_Application.StatusBar.SetText(
                    "Error ItemEvent: " + ex.Message,
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Error
                );
            }
        }

        private static void AgregarPestanaSpmSocioNegocios(string formUid)
        {
            SAPbouiCOM.Form form = SBO_Application.Forms.Item(formUid);

            // Evita agregar la pestaña dos veces
            if (ExisteItem(form, FolderSpm))
                return;

            form.Freeze(true);

            try
            {
                SAPbouiCOM.Item folderReferencia = ObtenerFolderReferencia(form);

                if (folderReferencia == null)
                {
                    throw new Exception(
                        "No se encontró una pestaña de referencia en el formulario de Socios de Negocio."
                    );
                }

                int topPestana = folderReferencia.Top;
                int leftNuevaPestana = folderReferencia.Left + folderReferencia.Width + 5;

                // Busca la última pestaña visible para colocar SPM después
                for (int i = 0; i < form.Items.Count; i++)
                {
                    SAPbouiCOM.Item item = form.Items.Item(i);

                    if (item.Type == BoFormItemTypes.it_FOLDER &&
                        Math.Abs(item.Top - topPestana) <= 5)
                    {
                        int finalItem = item.Left + item.Width;

                        if (finalItem + 5 > leftNuevaPestana)
                            leftNuevaPestana = finalItem + 5;
                    }
                }

                // Crear pestaña SPM
                SAPbouiCOM.Item fldItem = form.Items.Add(FolderSpm, BoFormItemTypes.it_FOLDER);
                fldItem.Left = leftNuevaPestana;
                fldItem.Top = topPestana;
                fldItem.Width = 65;
                fldItem.Height = folderReferencia.Height;

                SAPbouiCOM.Folder fld = (SAPbouiCOM.Folder)fldItem.Specific;
                fld.Caption = "SPM";
                fld.Pane = PaneSpm;
                fld.GroupWith(folderReferencia.UniqueID);

                // Crear UserDataSources
                AgregarUserDataSourceSiNoExiste(
                    form,
                    UdsCodigoSpm,
                    BoDataType.dt_SHORT_TEXT,
                    50
                );

                AgregarUserDataSourceSiNoExiste(
                    form,
                    UdsNombreSpm,
                    BoDataType.dt_SHORT_TEXT,
                    150
                );

                int leftBase = 25;
                int topBase = topPestana + 45;

                // Label Código
                SAPbouiCOM.Item lblCodigo = form.Items.Add(
                    ItemLblCodigo,
                    BoFormItemTypes.it_STATIC
                );

                lblCodigo.Left = leftBase;
                lblCodigo.Top = topBase;
                lblCodigo.Width = 120;
                lblCodigo.Height = 15;
                lblCodigo.FromPane = PaneSpm;
                lblCodigo.ToPane = PaneSpm;

                SAPbouiCOM.StaticText lblCodigoTxt =
                    (SAPbouiCOM.StaticText)lblCodigo.Specific;

                lblCodigoTxt.Caption = "Código cliente";

                // TextBox Código
                SAPbouiCOM.Item txtCodigo = form.Items.Add(
                    ItemTxtCodigo,
                    BoFormItemTypes.it_EDIT
                );

                txtCodigo.Left = leftBase + 130;
                txtCodigo.Top = topBase;
                txtCodigo.Width = 160;
                txtCodigo.Height = 15;
                txtCodigo.FromPane = PaneSpm;
                txtCodigo.ToPane = PaneSpm;

                SAPbouiCOM.EditText txtCodigoEdit =
                    (SAPbouiCOM.EditText)txtCodigo.Specific;

                txtCodigoEdit.DataBind.SetBound(true, "", UdsCodigoSpm);

                // Label Nombre
                SAPbouiCOM.Item lblNombre = form.Items.Add(
                    ItemLblNombre,
                    BoFormItemTypes.it_STATIC
                );

                lblNombre.Left = leftBase;
                lblNombre.Top = topBase + 25;
                lblNombre.Width = 120;
                lblNombre.Height = 15;
                lblNombre.FromPane = PaneSpm;
                lblNombre.ToPane = PaneSpm;

                SAPbouiCOM.StaticText lblNombreTxt =
                    (SAPbouiCOM.StaticText)lblNombre.Specific;

                lblNombreTxt.Caption = "Nombre cliente";

                // TextBox Nombre
                SAPbouiCOM.Item txtNombre = form.Items.Add(
                    ItemTxtNombre,
                    BoFormItemTypes.it_EDIT
                );

                txtNombre.Left = leftBase + 130;
                txtNombre.Top = topBase + 25;
                txtNombre.Width = 250;
                txtNombre.Height = 15;
                txtNombre.FromPane = PaneSpm;
                txtNombre.ToPane = PaneSpm;

                SAPbouiCOM.EditText txtNombreEdit =
                    (SAPbouiCOM.EditText)txtNombre.Specific;

                txtNombreEdit.DataBind.SetBound(true, "", UdsNombreSpm);

                // Botón Crear cliente
                SAPbouiCOM.Item btnCrear = form.Items.Add(
                    ItemBtnCrear,
                    BoFormItemTypes.it_BUTTON
                );

                btnCrear.Left = leftBase + 130;
                btnCrear.Top = topBase + 60;
                btnCrear.Width = 120;
                btnCrear.Height = 22;
                btnCrear.FromPane = PaneSpm;
                btnCrear.ToPane = PaneSpm;

                SAPbouiCOM.Button btnCrearCliente =
                    (SAPbouiCOM.Button)btnCrear.Specific;

                btnCrearCliente.Caption = "Crear cliente";

                SBO_Application.StatusBar.SetText(
                    "Pestaña SPM agregada al formulario de Socios de Negocio.",
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Success
                );
            }
            catch (Exception ex)
            {
                SBO_Application.StatusBar.SetText(
                    "Error agregando pestaña SPM: " + ex.Message,
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Error
                );
            }
            finally
            {
                form.Freeze(false);
            }
        }

        private static SAPbouiCOM.Item ObtenerFolderReferencia(SAPbouiCOM.Form form)
        {
            for (int i = 0; i < form.Items.Count; i++)
            {
                SAPbouiCOM.Item item = form.Items.Item(i);

                if (item.Type == BoFormItemTypes.it_FOLDER)
                    return item;
            }

            return null;
        }

        private static bool ExisteItem(SAPbouiCOM.Form form, string itemUid)
        {
            try
            {
                SAPbouiCOM.Item item = form.Items.Item(itemUid);
                return item != null;
            }
            catch
            {
                return false;
            }
        }

        private static void AgregarUserDataSourceSiNoExiste(
            SAPbouiCOM.Form form,
            string uid,
            BoDataType tipo,
            int longitud
        )
        {
            try
            {
                form.DataSources.UserDataSources.Item(uid);
            }
            catch
            {
                form.DataSources.UserDataSources.Add(uid, tipo, longitud);
            }
        }

        private static void CrearClienteDesdeSpm(string formUid)
        {
            SAPbouiCOM.Form form = SBO_Application.Forms.Item(formUid);

            string codigo = form.DataSources.UserDataSources
                .Item(UdsCodigoSpm)
                .ValueEx
                .Trim();

            string nombre = form.DataSources.UserDataSources
                .Item(UdsNombreSpm)
                .ValueEx
                .Trim();

            if (string.IsNullOrWhiteSpace(codigo))
            {
                SBO_Application.MessageBox("Captura el código del cliente.");
                return;
            }

            if (string.IsNullOrWhiteSpace(nombre))
            {
                SBO_Application.MessageBox("Captura el nombre del cliente.");
                return;
            }

            SAPbobsCOM.BusinessPartners bp = null;

            try
            {
                SAPbobsCOM.Company diCompany =
                    (SAPbobsCOM.Company)SBO_Application.Company.GetDICompany();

                if (diCompany == null || !diCompany.Connected)
                    throw new Exception("No se pudo obtener conexión DI API activa.");

                bp = (SAPbobsCOM.BusinessPartners)diCompany.GetBusinessObject(
                    SAPbobsCOM.BoObjectTypes.oBusinessPartners
                );

                if (bp.GetByKey(codigo))
                {
                    SBO_Application.MessageBox(
                        "Ya existe un socio de negocio con el código: " + codigo
                    );
                    return;
                }

                bp.CardCode = codigo;
                bp.CardName = nombre;
                bp.CardType = SAPbobsCOM.BoCardTypes.cCustomer;

                int resultado = bp.Add();

                if (resultado != 0)
                {
                    diCompany.GetLastError(out int errorCode, out string errorMessage);
                    throw new Exception(errorCode + " - " + errorMessage);
                }

                SBO_Application.MessageBox(
                    "Cliente creado correctamente.\n\n" +
                    "Código: " + codigo + "\n" +
                    "Nombre: " + nombre
                );

                form.DataSources.UserDataSources.Item(UdsCodigoSpm).ValueEx = "";
                form.DataSources.UserDataSources.Item(UdsNombreSpm).ValueEx = "";
            }
            catch (Exception ex)
            {
                SBO_Application.MessageBox("Error creando cliente:\n" + ex.Message);
            }
            finally
            {
                if (bp != null)
                {
                    Marshal.ReleaseComObject(bp);
                    bp = null;
                }
            }
        }

        private static void SBO_Application_AppEvent(BoAppEventTypes EventType)
        {
            if (EventType == BoAppEventTypes.aet_ShutDown ||
                EventType == BoAppEventTypes.aet_CompanyChanged ||
                EventType == BoAppEventTypes.aet_ServerTerminition)
            {
                WinForms.Application.ExitThread();
            }
        }
    }
}