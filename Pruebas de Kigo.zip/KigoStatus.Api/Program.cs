var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();

// Ruta principal para confirmar que el proyecto está activo.
app.MapGet("/", () =>
{
    return Results.Ok(new
    {
        application = "PruebaEstadoKigo",
        message = "API C# funcionando correctamente"
    });
});

// Endpoint de diagnóstico de nuestra API local.
app.MapGet("/api/health", () =>
{
    return Results.Ok(new
    {
        status = "OPERATIVO",
        service = "KigoStatus.Api",
        description = "La API local de diagnóstico está funcionando.",
        checkedAt = DateTimeOffset.Now
    });
});

app.Run();