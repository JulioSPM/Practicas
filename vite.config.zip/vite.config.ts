import { defineConfig } from 'vite';
import Vuetify, { transformAssetUrls } from 'vite-plugin-vuetify';
import Vue from '@vitejs/plugin-vue'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
    resolve: {
        alias: {
            "@": fileURLToPath(new URL('src', import.meta.url)),
        }
    },
    build:{
        target: "esnext",
        sourcemap: false
    },
    server: {
        port: 5192
    },
    plugins:[
        Vue({
            template: { transformAssetUrls },
        }),
        Vuetify(),
    ]
})