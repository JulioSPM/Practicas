import { createApp } from 'vue';
import App from './App.vue';
import { registerPlugins } from '@/plugins';
import { createHead } from '@unhead/vue/client';
import router from '@/plugins/router';
import Toast from "vue-toastification";
import "vue-toastification/dist/index.css";
import {TAB_SITE_TITLE} from './config/env.config.ts';

const app = createApp(App);
const head = createHead({
    init:[
        {
            titleTemplate: `%s - ${TAB_SITE_TITLE}`,
            htmlAttrs: {lang: "es-MX"}
        },
    ]
});


registerPlugins(app);
app.use(head);
app.use(router);
app.use(Toast);
app.mount('#app');
