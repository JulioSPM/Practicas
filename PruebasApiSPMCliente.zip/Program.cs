﻿using System;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using SAPbouiCOM;
using WinForms = System.Windows.Forms;

namespace AddonSPMClientes
{
    internal static class Program
    {
        private static SAPbouiCOM.Application SBO_Application;
        private static SAPbouiCOM.SboGuiApi SboGuiApi;

        // Formulario estándar de SAP B1:
        // Datos maestros de socio de negocios
        private const string FormTypeSocioNegocios = "134";

        // Pane personalizado para nuestra pestaña
        private const int PaneSpm = 99;

        // UserDataSources personalizados para crear cliente
        private const string UdsCodigoSpm = "UDSCOD";
        private const string UdsNombreSpm = "UDSNOM";
        private const string UdsRfcSpm = "UDSRFC";

        // UserDataSources personalizados para Service Layer
        private const string UdsBaseUrl = "UDSBASE";
        private const string UdsCompany = "UDSCOMP";
        private const string UdsUser = "UDSUSER";
        private const string UdsPass = "UDSPASS";
        private const string UdsMetodo = "UDSMET";
        private const string UdsEndpoint = "UDSENDP";
        private const string UdsBody = "UDSBODY";
        private const string UdsResponse = "UDSRESP";

        // IDs de controles UI API
        private const string FolderSpm = "fldSPM";

        // Controles Crear cliente
        private const string ItemLblCodigo = "lblCodS";
        private const string ItemTxtCodigo = "txtCodS";

        private const string ItemLblNombre = "lblNomS";
        private const string ItemTxtNombre = "txtNomS";

        private const string ItemLblRfc = "lblRfcS";
        private const string ItemTxtRfc = "txtRfcS";

        private const string ItemBtnCrear = "btnCrS";

        // Controles Service Layer
        private const string ItemLblBase = "lblBase";
        private const string ItemTxtBase = "txtBase";

        private const string ItemLblComp = "lblComp";
        private const string ItemTxtComp = "txtComp";

        private const string ItemLblUser = "lblUser";
        private const string ItemTxtUser = "txtUser";

        private const string ItemLblPass = "lblPass";
        private const string ItemTxtPass = "txtPass";

        private const string ItemLblMet = "lblMet";
        private const string ItemCmbMet = "cmbMet";

        private const string ItemLblEndp = "lblEndp";
        private const string ItemTxtEndp = "txtEndp";

        private const string ItemLblBody = "lblBody";
        private const string ItemTxtBody = "txtBody";

        private const string ItemLblResp = "lblResp";
        private const string ItemTxtResp = "txtResp";

        private const string ItemBtnLogin = "btnLogin";
        private const string ItemBtnSend = "btnSend";
        private const string ItemBtnBP = "btnBP";
        private const string ItemBtnClear = "btnClear";

        // Service Layer
        private static CookieContainer ServiceLayerCookies = new CookieContainer();
        private static string ServiceLayerBaseUrl = "";
        private static bool ServiceLayerLogueado = false;

        // Para pruebas con certificado autofirmado.
        // En producción se recomienda instalar el certificado y cambiar esto a false.
        private const bool IgnorarCertificadoSslSoloPruebas = true;

        [STAThread]
        private static void Main(string[] args)
        {
            try
            {
                ConectarConSap(args);
                RegistrarEventos();
                ConfigurarTls();

                SBO_Application.StatusBar.SetText(
                    "Add-On SPM Clientes conectado correctamente.",
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Success
                );

                WinForms.Application.Run();
            }
            catch (Exception ex)
            {
                try
                {
                    if (SBO_Application != null)
                    {
                        SBO_Application.MessageBox("Error inicializando Add-On:\n" + ex.Message);
                    }
                    else
                    {
                        WinForms.MessageBox.Show(ex.ToString(), "Error Add-On SPM");
                    }
                }
                catch
                {
                    WinForms.MessageBox.Show(ex.ToString(), "Error Add-On SPM");
                }
            }
        }

        private static void ConfigurarTls()
        {
            ServicePointManager.Expect100Continue = false;

            ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Tls12 |
                SecurityProtocolType.Tls11 |
                SecurityProtocolType.Tls;

            if (IgnorarCertificadoSslSoloPruebas)
            {
                ServicePointManager.ServerCertificateValidationCallback =
                    delegate { return true; };
            }
        }

        private static void ConectarConSap(string[] args)
        {
            if (args == null || args.Length == 0 || string.IsNullOrWhiteSpace(args[0]))
            {
                throw new Exception("No llegó el connection string de SAP.");
            }

            SboGuiApi = new SAPbouiCOM.SboGuiApi();
            SboGuiApi.Connect(args[0]);
            SBO_Application = SboGuiApi.GetApplication(-1);
        }

        private static void RegistrarEventos()
        {
            SBO_Application.ItemEvent += SBO_Application_ItemEvent;
            SBO_Application.AppEvent += SBO_Application_AppEvent;
        }

        private static void SBO_Application_ItemEvent(
            string FormUID,
            ref SAPbouiCOM.ItemEvent pVal,
            out bool BubbleEvent
        )
        {
            BubbleEvent = true;

            try
            {
                if (pVal.BeforeAction)
                    return;

                // Cuando SAP carga el formulario de Socios de Negocio
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_FORM_LOAD)
                {
                    AgregarPestanaSpmSocioNegocios(FormUID);
                    return;
                }

                // Cuando presionan la pestaña SPM
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_ITEM_PRESSED &&
                    pVal.ItemUID == FolderSpm)
                {
                    SAPbouiCOM.Form form = SBO_Application.Forms.Item(FormUID);
                    form.PaneLevel = PaneSpm;
                    return;
                }

                // Botón Crear cliente
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_ITEM_PRESSED &&
                    pVal.ItemUID == ItemBtnCrear)
                {
                    CrearClienteDesdeSpm(FormUID);
                    return;
                }

                // Botón Login Service Layer
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_ITEM_PRESSED &&
                    pVal.ItemUID == ItemBtnLogin)
                {
                    LoginServiceLayer(FormUID);
                    return;
                }

                // Botón Enviar request Service Layer
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_ITEM_PRESSED &&
                    pVal.ItemUID == ItemBtnSend)
                {
                    EnviarRequestServiceLayer(FormUID);
                    return;
                }

                // Botón GET socio actual
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_ITEM_PRESSED &&
                    pVal.ItemUID == ItemBtnBP)
                {
                    ConsultarSocioActual(FormUID);
                    return;
                }

                // Botón Limpiar respuesta
                if (pVal.FormTypeEx == FormTypeSocioNegocios &&
                    pVal.EventType == BoEventTypes.et_ITEM_PRESSED &&
                    pVal.ItemUID == ItemBtnClear)
                {
                    LimpiarRespuesta(FormUID);
                    return;
                }
            }
            catch (Exception ex)
            {
                SBO_Application.StatusBar.SetText(
                    "Error ItemEvent: " + ex.Message,
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Error
                );
            }
        }

        private static void AgregarPestanaSpmSocioNegocios(string formUid)
        {
            SAPbouiCOM.Form form = SBO_Application.Forms.Item(formUid);

            // Evita agregar la pestaña dos veces
            if (ExisteItem(form, FolderSpm))
                return;

            form.Freeze(true);

            try
            {
                SAPbouiCOM.Item folderReferencia = ObtenerFolderReferencia(form);

                if (folderReferencia == null)
                {
                    throw new Exception(
                        "No se encontró una pestaña de referencia en el formulario de Socios de Negocio."
                    );
                }

                int topPestana = folderReferencia.Top;
                int leftNuevaPestana = folderReferencia.Left + folderReferencia.Width + 5;

                // Busca la última pestaña visible para colocar SPM después
                for (int i = 0; i < form.Items.Count; i++)
                {
                    SAPbouiCOM.Item item = form.Items.Item(i);

                    if (item.Type == BoFormItemTypes.it_FOLDER &&
                        Math.Abs(item.Top - topPestana) <= 5)
                    {
                        int finalItem = item.Left + item.Width;

                        if (finalItem + 5 > leftNuevaPestana)
                            leftNuevaPestana = finalItem + 5;
                    }
                }

                // Crear pestaña SPM
                SAPbouiCOM.Item fldItem = form.Items.Add(FolderSpm, BoFormItemTypes.it_FOLDER);
                fldItem.Left = leftNuevaPestana;
                fldItem.Top = topPestana;
                fldItem.Width = 65;
                fldItem.Height = folderReferencia.Height;

                SAPbouiCOM.Folder fld = (SAPbouiCOM.Folder)fldItem.Specific;
                fld.Caption = "SPM";
                fld.Pane = PaneSpm;
                fld.GroupWith(folderReferencia.UniqueID);

                // UserDataSources para crear cliente
                AgregarUserDataSourceSiNoExiste(form, UdsCodigoSpm, BoDataType.dt_SHORT_TEXT, 50);
                AgregarUserDataSourceSiNoExiste(form, UdsNombreSpm, BoDataType.dt_SHORT_TEXT, 150);
                AgregarUserDataSourceSiNoExiste(form, UdsRfcSpm, BoDataType.dt_SHORT_TEXT, 20);

                // UserDataSources para Service Layer
                AgregarUserDataSourceSiNoExiste(form, UdsBaseUrl, BoDataType.dt_SHORT_TEXT, 254);
                AgregarUserDataSourceSiNoExiste(form, UdsCompany, BoDataType.dt_SHORT_TEXT, 100);
                AgregarUserDataSourceSiNoExiste(form, UdsUser, BoDataType.dt_SHORT_TEXT, 100);
                AgregarUserDataSourceSiNoExiste(form, UdsPass, BoDataType.dt_SHORT_TEXT, 100);
                AgregarUserDataSourceSiNoExiste(form, UdsMetodo, BoDataType.dt_SHORT_TEXT, 10);
                AgregarUserDataSourceSiNoExiste(form, UdsEndpoint, BoDataType.dt_SHORT_TEXT, 254);
                AgregarUserDataSourceSiNoExiste(form, UdsBody, BoDataType.dt_LONG_TEXT, 0);
                AgregarUserDataSourceSiNoExiste(form, UdsResponse, BoDataType.dt_LONG_TEXT, 0);

                int leftBase = 25;
                int topBase = topPestana + 45;

                // ================================
                // Sección Crear cliente
                // ================================

                CrearLabel(form, ItemLblCodigo, "Código cliente", leftBase, topBase, 120);
                CrearEditText(form, ItemTxtCodigo, UdsCodigoSpm, leftBase + 130, topBase, 160, false);

                CrearLabel(form, ItemLblNombre, "Nombre cliente", leftBase, topBase + 25, 120);
                CrearEditText(form, ItemTxtNombre, UdsNombreSpm, leftBase + 130, topBase + 25, 250, false);

                CrearLabel(form, ItemLblRfc, "RFC", leftBase, topBase + 50, 120);
                CrearEditText(form, ItemTxtRfc, UdsRfcSpm, leftBase + 130, topBase + 50, 160, false);

                CrearBoton(form, ItemBtnCrear, "Crear cliente", leftBase + 130, topBase + 85, 120);

                // ================================
                // Sección Service Layer tipo Postman
                // ================================

                int topApi = topBase + 125;

                CrearLabel(form, ItemLblBase, "URL Service Layer", leftBase, topApi, 120);
                CrearEditText(form, ItemTxtBase, UdsBaseUrl, leftBase + 130, topApi, 360, false);

                CrearLabel(form, ItemLblComp, "CompanyDB", leftBase, topApi + 25, 120);
                CrearEditText(form, ItemTxtComp, UdsCompany, leftBase + 130, topApi + 25, 160, false);

                CrearLabel(form, ItemLblUser, "Usuario", leftBase, topApi + 50, 120);
                CrearEditText(form, ItemTxtUser, UdsUser, leftBase + 130, topApi + 50, 160, false);

                CrearLabel(form, ItemLblPass, "Password", leftBase + 310, topApi + 50, 80);
                CrearEditText(form, ItemTxtPass, UdsPass, leftBase + 390, topApi + 50, 100, true);

                CrearLabel(form, ItemLblMet, "Método", leftBase, topApi + 80, 120);
                CrearComboMetodo(form, ItemCmbMet, UdsMetodo, leftBase + 130, topApi + 80, 90);

                CrearLabel(form, ItemLblEndp, "Endpoint", leftBase + 240, topApi + 80, 70);
                CrearEditText(form, ItemTxtEndp, UdsEndpoint, leftBase + 310, topApi + 80, 260, false);

                CrearBoton(form, ItemBtnLogin, "Login SL", leftBase + 585, topApi + 20, 90);
                CrearBoton(form, ItemBtnSend, "Enviar", leftBase + 585, topApi + 50, 90);
                CrearBoton(form, ItemBtnBP, "GET socio", leftBase + 585, topApi + 80, 90);
                CrearBoton(form, ItemBtnClear, "Limpiar", leftBase + 585, topApi + 110, 90);

                CrearLabel(form, ItemLblBody, "Body JSON", leftBase, topApi + 115, 120);
                CrearEditTextGrande(form, ItemTxtBody, UdsBody, leftBase + 130, topApi + 115, 440, 75);

                CrearLabel(form, ItemLblResp, "Respuesta", leftBase, topApi + 200, 120);
                CrearEditTextGrande(form, ItemTxtResp, UdsResponse, leftBase + 130, topApi + 200, 545, 120);

                // Valores por defecto
                SetValorUds(form, UdsBaseUrl, "https://localhost:50000/b1s/v2");
                SetValorUds(form, UdsMetodo, "GET");
                SetValorUds(form, UdsEndpoint, "BusinessPartners?$select=CardCode,CardName&$top=5");
                SetValorUds(form, UdsBody, "");

                SBO_Application.StatusBar.SetText(
                    "Pestaña SPM agregada al formulario de Socios de Negocio.",
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Success
                );
            }
            catch (Exception ex)
            {
                SBO_Application.StatusBar.SetText(
                    "Error agregando pestaña SPM: " + ex.Message,
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Error
                );
            }
            finally
            {
                form.Freeze(false);
            }
        }

        private static void CrearLabel(
            SAPbouiCOM.Form form,
            string uid,
            string caption,
            int left,
            int top,
            int width
        )
        {
            SAPbouiCOM.Item item = form.Items.Add(uid, BoFormItemTypes.it_STATIC);
            item.Left = left;
            item.Top = top;
            item.Width = width;
            item.Height = 15;
            item.FromPane = PaneSpm;
            item.ToPane = PaneSpm;

            SAPbouiCOM.StaticText lbl = (SAPbouiCOM.StaticText)item.Specific;
            lbl.Caption = caption;
        }

        private static void CrearEditText(
            SAPbouiCOM.Form form,
            string uid,
            string uds,
            int left,
            int top,
            int width,
            bool password
        )
        {
            SAPbouiCOM.Item item = form.Items.Add(uid, BoFormItemTypes.it_EDIT);
            item.Left = left;
            item.Top = top;
            item.Width = width;
            item.Height = 15;
            item.FromPane = PaneSpm;
            item.ToPane = PaneSpm;

            SAPbouiCOM.EditText edit = (SAPbouiCOM.EditText)item.Specific;
            edit.DataBind.SetBound(true, "", uds);

            if (password)
                edit.IsPassword = true;
        }

        private static void CrearEditTextGrande(
            SAPbouiCOM.Form form,
            string uid,
            string uds,
            int left,
            int top,
            int width,
            int height
        )
        {
            SAPbouiCOM.Item item = form.Items.Add(uid, BoFormItemTypes.it_EXTEDIT);
            item.Left = left;
            item.Top = top;
            item.Width = width;
            item.Height = height;
            item.FromPane = PaneSpm;
            item.ToPane = PaneSpm;

            SAPbouiCOM.EditText edit = (SAPbouiCOM.EditText)item.Specific;
            edit.DataBind.SetBound(true, "", uds);
        }

        private static void CrearComboMetodo(
            SAPbouiCOM.Form form,
            string uid,
            string uds,
            int left,
            int top,
            int width
        )
        {
            SAPbouiCOM.Item item = form.Items.Add(uid, BoFormItemTypes.it_COMBO_BOX);
            item.Left = left;
            item.Top = top;
            item.Width = width;
            item.Height = 15;
            item.FromPane = PaneSpm;
            item.ToPane = PaneSpm;

            SAPbouiCOM.ComboBox combo = (SAPbouiCOM.ComboBox)item.Specific;
            combo.DataBind.SetBound(true, "", uds);

            combo.ValidValues.Add("GET", "GET");
            combo.ValidValues.Add("POST", "POST");
            combo.ValidValues.Add("PATCH", "PATCH");
            combo.ValidValues.Add("DELETE", "DELETE");

            combo.Select("GET", BoSearchKey.psk_ByValue);
        }

        private static void CrearBoton(
            SAPbouiCOM.Form form,
            string uid,
            string caption,
            int left,
            int top,
            int width
        )
        {
            SAPbouiCOM.Item item = form.Items.Add(uid, BoFormItemTypes.it_BUTTON);
            item.Left = left;
            item.Top = top;
            item.Width = width;
            item.Height = 22;
            item.FromPane = PaneSpm;
            item.ToPane = PaneSpm;

            SAPbouiCOM.Button btn = (SAPbouiCOM.Button)item.Specific;
            btn.Caption = caption;
        }

        private static SAPbouiCOM.Item ObtenerFolderReferencia(SAPbouiCOM.Form form)
        {
            for (int i = 0; i < form.Items.Count; i++)
            {
                SAPbouiCOM.Item item = form.Items.Item(i);

                if (item.Type == BoFormItemTypes.it_FOLDER)
                    return item;
            }

            return null;
        }

        private static bool ExisteItem(SAPbouiCOM.Form form, string itemUid)
        {
            try
            {
                SAPbouiCOM.Item item = form.Items.Item(itemUid);
                return item != null;
            }
            catch
            {
                return false;
            }
        }

        private static void AgregarUserDataSourceSiNoExiste(
            SAPbouiCOM.Form form,
            string uid,
            BoDataType tipo,
            int longitud
        )
        {
            try
            {
                form.DataSources.UserDataSources.Item(uid);
            }
            catch
            {
                form.DataSources.UserDataSources.Add(uid, tipo, longitud);
            }
        }

        private static string GetValorUds(SAPbouiCOM.Form form, string uds)
        {
            return form.DataSources.UserDataSources.Item(uds).ValueEx.Trim();
        }

        private static void SetValorUds(SAPbouiCOM.Form form, string uds, string valor)
        {
            form.DataSources.UserDataSources.Item(uds).ValueEx = valor ?? "";
        }

        // ============================================================
        // Crear cliente por DI API
        // ============================================================

        private static void CrearClienteDesdeSpm(string formUid)
        {
            SAPbouiCOM.Form form = SBO_Application.Forms.Item(formUid);

            string codigo = "";
            string nombre = "";
            string rfc = "";

            try
            {
                codigo = ((SAPbouiCOM.EditText)form.Items.Item(ItemTxtCodigo).Specific)
                    .Value
                    .Trim();

                nombre = ((SAPbouiCOM.EditText)form.Items.Item(ItemTxtNombre).Specific)
                    .Value
                    .Trim();

                rfc = ((SAPbouiCOM.EditText)form.Items.Item(ItemTxtRfc).Specific)
                    .Value
                    .Trim();
            }
            catch (Exception ex)
            {
                SBO_Application.MessageBox("No se pudieron leer los campos SPM:\n" + ex.Message);
                return;
            }

            if (string.IsNullOrWhiteSpace(codigo))
            {
                SBO_Application.MessageBox("Captura el código del cliente.");
                return;
            }

            if (string.IsNullOrWhiteSpace(nombre))
            {
                SBO_Application.MessageBox("Captura el nombre del cliente.");
                return;
            }

            if (string.IsNullOrWhiteSpace(rfc))
            {
                SBO_Application.MessageBox("Captura el RFC del cliente.");
                return;
            }

            SAPbobsCOM.BusinessPartners bp = null;

            try
            {
                SAPbobsCOM.Company diCompany =
                    (SAPbobsCOM.Company)SBO_Application.Company.GetDICompany();

                if (diCompany == null || !diCompany.Connected)
                    throw new Exception("No se pudo obtener conexión DI API activa.");

                bp = (SAPbobsCOM.BusinessPartners)diCompany.GetBusinessObject(
                    SAPbobsCOM.BoObjectTypes.oBusinessPartners
                );

                if (bp.GetByKey(codigo))
                {
                    SBO_Application.MessageBox(
                        "Ya existe un socio de negocio con el código: " + codigo
                    );
                    return;
                }

                bp.CardCode = codigo;
                bp.CardName = nombre;
                bp.CardType = SAPbobsCOM.BoCardTypes.cCustomer;

                // RFC / LicTradNum en OCRD
                bp.FederalTaxID = rfc;

                int resultado = bp.Add();

                if (resultado != 0)
                {
                    diCompany.GetLastError(out int errorCode, out string errorMessage);
                    throw new Exception(errorCode + " - " + errorMessage);
                }

                SBO_Application.MessageBox(
                    "Cliente creado correctamente.\n\n" +
                    "Código: " + codigo + "\n" +
                    "Nombre: " + nombre + "\n" +
                    "RFC: " + rfc
                );

                ((SAPbouiCOM.EditText)form.Items.Item(ItemTxtCodigo).Specific).Value = "";
                ((SAPbouiCOM.EditText)form.Items.Item(ItemTxtNombre).Specific).Value = "";
                ((SAPbouiCOM.EditText)form.Items.Item(ItemTxtRfc).Specific).Value = "";

                AbrirClienteCreado(codigo);
            }
            catch (Exception ex)
            {
                SBO_Application.MessageBox("Error creando cliente:\n" + ex.Message);
            }
            finally
            {
                if (bp != null)
                {
                    Marshal.ReleaseComObject(bp);
                    bp = null;
                }
            }
        }

        private static void AbrirClienteCreado(string codigoCliente)
        {
            try
            {
                SBO_Application.OpenForm(
                    SAPbouiCOM.BoFormObjectEnum.fo_BusinessPartner,
                    "",
                    codigoCliente
                );
            }
            catch (Exception ex)
            {
                SBO_Application.StatusBar.SetText(
                    "Cliente creado, pero no se pudo abrir automáticamente: " + ex.Message,
                    BoMessageTime.bmt_Short,
                    BoStatusBarMessageType.smt_Warning
                );
            }
        }

        // ============================================================
        // Service Layer
        // ============================================================

        private static void LoginServiceLayer(string formUid)
        {
            SAPbouiCOM.Form form = SBO_Application.Forms.Item(formUid);

            string baseUrl = GetValorUds(form, UdsBaseUrl);
            string companyDb = GetValorUds(form, UdsCompany);
            string usuario = GetValorUds(form, UdsUser);
            string password = GetValorUds(form, UdsPass);

            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                SBO_Application.MessageBox("Captura la URL base de Service Layer.");
                return;
            }

            if (string.IsNullOrWhiteSpace(companyDb))
            {
                SBO_Application.MessageBox("Captura el CompanyDB.");
                return;
            }

            if (string.IsNullOrWhiteSpace(usuario))
            {
                SBO_Application.MessageBox("Captura el usuario.");
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                SBO_Application.MessageBox("Captura el password.");
                return;
            }

            try
            {
                ServiceLayerBaseUrl = NormalizarBaseUrl(baseUrl);
                ServiceLayerCookies = new CookieContainer();

                string urlLogin = ConstruirUrl(ServiceLayerBaseUrl, "Login");

                string jsonLogin =
                    "{" +
                    "\"CompanyDB\":\"" + EscaparJson(companyDb) + "\"," +
                    "\"UserName\":\"" + EscaparJson(usuario) + "\"," +
                    "\"Password\":\"" + EscaparJson(password) + "\"" +
                    "}";

                string jsonLoginVisible =
                    "{" +
                    "\"CompanyDB\":\"" + EscaparJson(companyDb) + "\"," +
                    "\"UserName\":\"" + EscaparJson(usuario) + "\"," +
                    "\"Password\":\"********\"" +
                    "}";

                SetValorUds(
                    form,
                    UdsResponse,
                    "URL LOGIN:\r\n" + urlLogin +
                    "\r\n\r\nJSON ENVIADO:\r\n" + jsonLoginVisible +
                    "\r\n\r\nEnviando..."
                );

                HttpResult result = EjecutarHttp(
                    urlLogin,
                    "POST",
                    jsonLogin,
                    ServiceLayerCookies,
                    false
                );

                SetValorUds(form, UdsResponse, FormatearRespuesta(result, urlLogin, jsonLoginVisible));

                if (result.StatusCode >= 200 && result.StatusCode <= 299)
                {
                    ServiceLayerLogueado = true;

                    SBO_Application.StatusBar.SetText(
                        "Login correcto en Service Layer.",
                        BoMessageTime.bmt_Short,
                        BoStatusBarMessageType.smt_Success
                    );
                }
                else
                {
                    ServiceLayerLogueado = false;

                    SBO_Application.MessageBox(
                        "No se pudo iniciar sesión en Service Layer.\n\n" +
                        "HTTP " + result.StatusCode + " " + result.StatusDescription + "\n\n" +
                        "Revisa el campo Respuesta para ver el detalle completo."
                    );
                }
            }
            catch (Exception ex)
            {
                ServiceLayerLogueado = false;
                SBO_Application.MessageBox("Error en Login Service Layer:\n" + ex.Message);
            }
        }

        private static void EnviarRequestServiceLayer(string formUid)
        {
            SAPbouiCOM.Form form = SBO_Application.Forms.Item(formUid);

            string baseUrl = GetValorUds(form, UdsBaseUrl);
            string metodo = GetValorUds(form, UdsMetodo).ToUpperInvariant();
            string endpoint = GetValorUds(form, UdsEndpoint);
            string body = GetValorUds(form, UdsBody);

            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                SBO_Application.MessageBox("Captura la URL base de Service Layer.");
                return;
            }

            if (string.IsNullOrWhiteSpace(metodo))
            {
                SBO_Application.MessageBox("Selecciona el método HTTP.");
                return;
            }

            if (string.IsNullOrWhiteSpace(endpoint))
            {
                SBO_Application.MessageBox("Captura el endpoint.");
                return;
            }

            if (!ServiceLayerLogueado)
            {
                int respuesta = SBO_Application.MessageBox(
                    "Todavía no hay login activo en Service Layer.\n\n¿Deseas enviar de todos modos?",
                    1,
                    "Sí",
                    "No"
                );

                if (respuesta != 1)
                    return;
            }

            try
            {
                ServiceLayerBaseUrl = NormalizarBaseUrl(baseUrl);

                string url = ConstruirUrl(ServiceLayerBaseUrl, endpoint);

                bool enviarBody =
                    metodo == "POST" ||
                    metodo == "PATCH" ||
                    metodo == "PUT";

                HttpResult result = EjecutarHttp(
                    url,
                    metodo,
                    enviarBody ? body : "",
                    ServiceLayerCookies,
                    true
                );

                SetValorUds(form, UdsResponse, FormatearRespuesta(result, url, enviarBody ? body : ""));

                if (result.StatusCode >= 200 && result.StatusCode <= 299)
                {
                    SBO_Application.StatusBar.SetText(
                        "Request ejecutado correctamente. HTTP " + result.StatusCode,
                        BoMessageTime.bmt_Short,
                        BoStatusBarMessageType.smt_Success
                    );
                }
                else
                {
                    SBO_Application.StatusBar.SetText(
                        "Service Layer respondió HTTP " + result.StatusCode,
                        BoMessageTime.bmt_Short,
                        BoStatusBarMessageType.smt_Warning
                    );
                }
            }
            catch (Exception ex)
            {
                SBO_Application.MessageBox("Error enviando request:\n" + ex.Message);
            }
        }

        private static void ConsultarSocioActual(string formUid)
        {
            SAPbouiCOM.Form form = SBO_Application.Forms.Item(formUid);

            string cardCode = LeerCardCodeActual(form);

            if (string.IsNullOrWhiteSpace(cardCode))
            {
                SBO_Application.MessageBox(
                    "No se pudo leer el CardCode actual del formulario de Socio de Negocios."
                );
                return;
            }

            string endpoint = "BusinessPartners('" + EscaparODataKey(cardCode) + "')";

            SetValorUds(form, UdsMetodo, "GET");
            SetValorUds(form, UdsEndpoint, endpoint);
            SetValorUds(form, UdsBody, "");

            EnviarRequestServiceLayer(formUid);
        }

        private static string LeerCardCodeActual(SAPbouiCOM.Form form)
        {
            try
            {
                // En muchos formularios estándar de Socio de Negocios,
                // el item 5 corresponde al CardCode.
                if (ExisteItem(form, "5"))
                {
                    string valor = ((SAPbouiCOM.EditText)form.Items.Item("5").Specific)
                        .Value
                        .Trim();

                    if (!string.IsNullOrWhiteSpace(valor))
                        return valor;
                }
            }
            catch
            {
            }

            try
            {
                SAPbouiCOM.DBDataSource ds = form.DataSources.DBDataSources.Item("OCRD");

                string valor = ds.GetValue("CardCode", 0).Trim();

                if (!string.IsNullOrWhiteSpace(valor))
                    return valor;
            }
            catch
            {
            }

            return "";
        }

        private static void LimpiarRespuesta(string formUid)
        {
            SAPbouiCOM.Form form = SBO_Application.Forms.Item(formUid);
            SetValorUds(form, UdsResponse, "");
        }

        private static string NormalizarBaseUrl(string baseUrl)
        {
            string url = baseUrl.Trim().TrimEnd('/');

            // Si por error capturan /Login, lo quitamos.
            if (url.EndsWith("/Login", StringComparison.OrdinalIgnoreCase))
            {
                url = url.Substring(0, url.Length - "/Login".Length).TrimEnd('/');
            }

            // Si la URL trae más cosas después de /b1s/v1, se recorta correctamente.
            int idxV1 = url.IndexOf("/b1s/v1", StringComparison.OrdinalIgnoreCase);
            if (idxV1 >= 0)
            {
                return url.Substring(0, idxV1) + "/b1s/v1";
            }

            // Si la URL trae más cosas después de /b1s/v2, se recorta correctamente.
            int idxV2 = url.IndexOf("/b1s/v2", StringComparison.OrdinalIgnoreCase);
            if (idxV2 >= 0)
            {
                return url.Substring(0, idxV2) + "/b1s/v2";
            }

            // Si no trae versión, usamos v2 por defecto.
            return url + "/b1s/v2";
        }

        private static string ConstruirUrl(string baseUrl, string endpoint)
        {
            string endp = endpoint.Trim();

            if (endp.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                endp.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                return endp;
            }

            endp = endp.TrimStart('/');

            return baseUrl.TrimEnd('/') + "/" + endp;
        }

        private static HttpResult EjecutarHttp(
            string url,
            string metodo,
            string body,
            CookieContainer cookies,
            bool incluirPreferReturnNoContent
        )
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            request.Method = metodo;
            request.ContentType = "application/json; charset=utf-8";
            request.Accept = "application/json";
            request.CookieContainer = cookies;
            request.Timeout = 120000;
            request.ReadWriteTimeout = 120000;
            request.KeepAlive = true;

            if (incluirPreferReturnNoContent &&
                (metodo == "POST" || metodo == "PATCH" || metodo == "PUT"))
            {
                request.Headers.Add("Prefer", "return-no-content");
            }

            bool metodoConBody =
                metodo == "POST" ||
                metodo == "PATCH" ||
                metodo == "PUT";

            if (metodoConBody)
            {
                if (body == null)
                    body = "";

                byte[] bytes = Encoding.UTF8.GetBytes(body);
                request.ContentLength = bytes.Length;

                using (Stream stream = request.GetRequestStream())
                {
                    stream.Write(bytes, 0, bytes.Length);
                }
            }

            try
            {
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    string responseBody = LeerResponseBody(response);

                    return new HttpResult
                    {
                        StatusCode = (int)response.StatusCode,
                        StatusDescription = response.StatusDescription,
                        Body = responseBody
                    };
                }
            }
            catch (WebException webEx)
            {
                if (webEx.Response != null)
                {
                    using (HttpWebResponse response = (HttpWebResponse)webEx.Response)
                    {
                        string responseBody = LeerResponseBody(response);

                        return new HttpResult
                        {
                            StatusCode = (int)response.StatusCode,
                            StatusDescription = response.StatusDescription,
                            Body = responseBody
                        };
                    }
                }

                throw;
            }
        }

        private static string LeerResponseBody(HttpWebResponse response)
        {
            using (Stream stream = response.GetResponseStream())
            {
                if (stream == null)
                    return "";

                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    return reader.ReadToEnd();
                }
            }
        }

        private static string FormatearRespuesta(HttpResult result, string url, string requestBody)
        {
            string texto =
                "URL:\r\n" + url +
                "\r\n\r\nREQUEST BODY:\r\n" + (requestBody ?? "") +
                "\r\n\r\nHTTP " + result.StatusCode + " " + result.StatusDescription +
                "\r\n\r\nRESPONSE BODY:\r\n" + (result.Body ?? "");

            if (texto.Length > 30000)
            {
                texto = texto.Substring(0, 30000) +
                    "\r\n\r\n--- RESPUESTA RECORTADA POR LONGITUD ---";
            }

            return texto;
        }

        private static string EscaparJson(string valor)
        {
            if (valor == null)
                return "";

            return valor
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r", "\\r")
                .Replace("\n", "\\n")
                .Replace("\t", "\\t");
        }

        private static string EscaparODataKey(string valor)
        {
            if (valor == null)
                return "";

            return valor.Replace("'", "''");
        }

        private static void SBO_Application_AppEvent(BoAppEventTypes EventType)
        {
            if (EventType == BoAppEventTypes.aet_ShutDown ||
                EventType == BoAppEventTypes.aet_CompanyChanged ||
                EventType == BoAppEventTypes.aet_ServerTerminition)
            {
                WinForms.Application.ExitThread();
            }
        }

        private class HttpResult
        {
            public int StatusCode { get; set; }
            public string StatusDescription { get; set; }
            public string Body { get; set; }
        }
    }
}