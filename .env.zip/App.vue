<template>
  <v-app>
    <AppBar v-if="$route.meta.layout1"/>
    <v-main>
      <routerView/>
    </v-main>
    <AppFooter v-if="$route.meta.layout1"/>
  </v-app>
</template>
<script setup lang="ts">
import AppFooter from './components/layouts/Footer/AppFooter.vue';
import AppBar from './components/layouts/Menu/AppBar.vue';

</script>
<style src="./scss/main.scss">
</style>
<style>
.v-main{
  background: #F5F6F7;
}
</style>
