import '@mdi/font/css/materialdesignicons.css'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import 'vuetify/styles'
import { es } from 'vuetify/locale'

import { createVuetify } from 'vuetify'

export default createVuetify({
  ssr: true,
  icons: {
    defaultSet: 'mdi',
  },
  theme: {
    defaultTheme: 'light',
  },
  locale:{
    locale: 'es',
    fallback: 'es',
    messages: {es}
  },
  components,
  directives
})
