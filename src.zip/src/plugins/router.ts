const Login = () => import("@/components/Authentication/Login.vue");
const Home = () => import("@/components/Dashboard/Home.vue");
const Cot_Editar = () => import("@/components/Cotizaciones/Editar/Cot_Editar.vue");
import Error404 from "@/components/NotFound/Error404.vue";
const Detalle = () => import("@/components/Cotizaciones/Detalle.vue");
const Cot_Reporte = () => import("@/components/Cotizaciones/Reportes/Cot_Reporte.vue");
const Cot_Solicitud = () => import("@/components/Cotizaciones/Crear/Cot_Solicitud.vue");
const Cot_Pendiente = () => import("@/components/Cotizaciones/Pendiente/Cot_Pendiente.vue");
import { API_URL } from "@/config/env.config";

import { createWebHistory, createRouter } from "vue-router";

const routes = [
    {path: '/', name: "Home", component: Home, meta: { 
        layout1: true,
        requiresAuth: true,
        roles: null
    }},
    {path: '/login', name: "Login", component: Login, meta: {
        layout1: false,
        requiresAuth: false,
        roles: null
    }},
    {path: '/cotizaciones/crear', name: "CrearCotizaciones", component: Cot_Solicitud, meta: { 
        layout1: true,
        requiresAuth: true,
        roles: null
    }},
    {path: '/cotizaciones/pendiente', name: "CotizacionesPendiente", component: Cot_Pendiente, meta: { 
        layout1: true,
        requiresAuth: true,
        roles: null 
    }},
    {path: '/cotizaciones/reporte', name: "CotizacionesReporte", component: Cot_Reporte, meta: { 
        layout1: true,
        requiresAuth: true, 
        roles: null
    }},
    {path: '/cotizaciones/:id', name: "DetalleCotizacion", component: Detalle, meta: {
        layout1: true,
        requiresAuth: true,
        roles: null,
    }},
    {path: '/cotizaciones/editar/:id', name: "EditarCotizacion", component: Cot_Editar, meta: {
        layout1: true,
        requiresAuth: true,
        roles: null,
    }},
    {path: '/:pathMatch(.*)*', name: "NotFound", component: Error404, meta: {
        layout1: false,
        requiresAuth: false,
        transferEnabled: false,
        purchaseRequestEnabled: false,
        roles: null
    }}
]

const router = createRouter({
    history: createWebHistory(),
    routes,
});


router.beforeEach(async (to) => {
    const requiresAuth = Boolean(to.meta.requiresAuth);
    const pathRoles = to.meta.roles as string[] | null;

    try {
        const response = await fetch(`${API_URL}/api/auth/user-info`, {
            method: "GET",
            credentials: "include",
        });

        if (response.status === 401 || response.status === 404) {
            return requiresAuth ? { name: "Login" } : true;
        }

        if (!response.ok) {
            console.error(`No se pudo validar la sesión. Código: ${response.status}`);
            return { name: "NotFound" };
        }

        const userInfo = await response.json();

        if (!requiresAuth && to.name === "Login") {
            return { name: "Home" };
        }

        if (pathRoles !== null && !pathRoles.includes(String(userInfo.rol).trim())) {
            return { name: "Home" };
        }

        if (to.name === "DetalleCotizacion" || to.name === "EditarCotizacion") {
            const params = new URLSearchParams({ id: String(to.params.id) });
            const existsResponse = await fetch(`${API_URL}/api/cotizaciones/exist?${params}`, {
                method: "GET",
                credentials: "include",
            });

            if (existsResponse.status === 401) {
                return { name: "Login" };
            }

            if (!existsResponse.ok) {
                return { name: "NotFound" };
            }
        }

        return true;
    } catch (error) {
        console.error("No se pudo comunicar con la API:", error);
        return { name: "NotFound" };
    }
});

export default router;
