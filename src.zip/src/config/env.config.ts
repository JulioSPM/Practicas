//@ts-ignore
export const API_URL = import.meta.env.VITE_API_URL;
//@ts-ignore
export const TAB_SITE_TITLE = import.meta.env.VITE_TAB_SITE_TITLE;
//@ts-ignore
export const DEFAULT_SALESQUOT_TAX_CODE = import.meta.env.VITE_DEFAULT_SALESQUOT_TAX_CODE;
//@ts-ignore
export const COPYRIGHT_MSG = import.meta.env.VITE_COPYRIGHT_MSG;
//@ts-ignore
export const LOGO_PATH = import.meta.env.VITE_LOGO_PATH || "/Imágenes/SPM.png";
