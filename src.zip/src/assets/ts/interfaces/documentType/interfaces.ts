import { type Ref } from "vue"
import type { SelectField } from "../pages/interfaces"

export interface QuotationArticleInterface{
    article: Ref<string | null>,
    articleSearchElements: Ref<SelectField[]>,
    articleSearchVal: Ref<string>,
    loadingSearchArtField: Ref<boolean>,
    description: Ref<string>,
    unitPrice: Ref<number | string>,
    amount: Ref<number | string>,
    lineTotal: Ref<number>,
    prcntDiscount: Ref<string>,
    impuesto: Ref<string>,
    dim1: Ref<string>,
    dim2: Ref<string>,
    dim3: Ref<string>,
    dim4: Ref<string>,
    dim5: Ref<string>,
}

export interface DocTypeHeaders{
    title: string,
    key: string,
    align: 'left' | 'center' | 'right' | 'justify' | 'start' | 'end',
    width: number,
    enabled: boolean
}
