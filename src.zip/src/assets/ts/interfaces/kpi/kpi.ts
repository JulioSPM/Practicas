import type { Ref } from "vue";

export interface KPIGroup {
createdQuot: Ref<string>, 
pendingQuot: Ref<string>, 
releasedQuot: Ref<string>, 
failedQuot: Ref<string>, 
isAdmin: Ref<boolean>
}
