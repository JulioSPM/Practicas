import type { Ref } from "vue"

export interface PageBreadCrumb{
    title: string,
    disabled: boolean,
    href: string
}

export interface SelectField{
    title: string,
    value: string
}

export interface SelectField2{
    title: string, 
    subtitle: string
}

export interface DimensionDescription{
    enabled: Ref<boolean>,
    values: Ref<SelectField2[]>
}

export interface ERPSalesQuotationArticle{
    article: string,
    description: string,
    quantity: string,
    unitPrice: string,
    prcntDiscount: string,
    taxCode: string,
    total: string,
    dim1: string,
    dim2: string,
    dim3: string,
    dim4: string,
    dim5: string,
}

export interface SalesQuotation{
    date1: string,
    date2: string,
    date3: string,
    client: string,
    retailEmployee: string,
    ref: string,
    comm: string,
    project: string,
    projectType: string,
    quotationType: string,
    prcntPaymentAdvance: string,
    prcntPaymentStarted: string,
    documentLines: ERPSalesQuotationArticle[]
}

export interface SalesQuotationInfo{
    failed: Ref<boolean>,
    sapUploaded: Ref<boolean>,
    docId: Ref<string>,
    docDate: Ref<string>,
    docDueDate: Ref<string>
    taxDate: Ref<string>
    clientId: Ref<string>,
    clientName: Ref<string>,
    retailSeller: Ref<string>,
    employeeID: Ref<string>,
    employeeName: Ref<string>,
    comments: Ref<string>,
    ref: Ref<string>,
    docStatus: Ref<string>,
    docEntrySAP: Ref<string>,
    proyecto: Ref<string>,
    anticipo: Ref<string>,
    proyectoArrancado: Ref<string>,
    tipoCotizador: Ref<string>,
    cotizacion: Ref<string>,
    documentLines: Ref<ERPSalesQuotationArticle[]>
} 