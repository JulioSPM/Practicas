import type { QuotationArticleInterface } from "@/assets/ts/interfaces/documentType/interfaces";

class QuotationArticle{
    #rows: QuotationArticleInterface[];
    
    constructor(){
        this.#rows = [];
    }

    GetRows(): QuotationArticleInterface[]{
        return this.#rows;
    }
    
    AddRow(row: QuotationArticleInterface): void{
        this.#rows.push(row);
    }

    Length(): number{
        return this.#rows.length;
    }

    ClearTable(): void{
        this.#rows.length = 0;
    }

    RemoveRow(row: number): void{
        this.#rows.splice(row, 1);
    }

    CalculateTotal(): number{
        let total: number = 0.00;
        this.#rows.forEach(row =>{
            const basePrice: number = Number(row.amount.value) * Number(row.unitPrice.value);
            const discountPercentage: number = isNaN(Number(row.prcntDiscount.value)) ? 0.00 : Number(row.prcntDiscount.value);
            let discount = (100 - discountPercentage) / 100;
            total += basePrice * discount;
        })

        return total;
    }

    GetRow(index: number): QuotationArticleInterface{
        return this.#rows[index];
    }
}

export default QuotationArticle;