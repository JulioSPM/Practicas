import type { PageBreadCrumb } from '@/assets/ts/interfaces/pages/interfaces';

class BreadCrumb{
    #items: PageBreadCrumb[];

    constructor(){
        this.#items = [{
            title: "Inicio",
            disabled: false,
            href: "/", 
        }];
    }

    GetItems(){
        return this.#items;
    } 

    SetItems(element: PageBreadCrumb){
        this.#items.push(element);
    }
}

export default BreadCrumb;