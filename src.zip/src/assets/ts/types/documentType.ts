import type { ArticleInterface } from "../interfaces/documentType/interfaces";

//export type documentType = ArticleInterface[];