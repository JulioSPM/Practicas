<template>
    <v-app-bar :elevation="2">
        <template v-slot:prepend>
            <v-app-bar-nav-icon @click.stop="verticalMenu = !verticalMenu"></v-app-bar-nav-icon>
        </template>

        <v-app-bar-title class="ml-2">
            <RouterLink to="/" class="text-decoration-none" style="color: black;">
                <div class="d-flex align-center">
                    <img :src="LOGO_PATH" alt="SPM" class="app-logo" />
                    <p class="ml-1 site-title">{{ TAB_SITE_TITLE }}</p>
                </div>
            </RouterLink>
        </v-app-bar-title>

        <v-menu :close-on-content-click="false" transition="slide-y-transition">
            <template v-slot:activator="{props}">
                <v-btn class="text-none" icon="mdi-account-circle-outline" v-bind="props"></v-btn>
            </template>
            <v-card color="rgba(255, 255, 255, 0.6)" width="200" class="px-3 py-2">
                <p class="text-center ma-0">{{ profileMenu.userName.value }}</p>
                <v-divider color="B9B9B9" :thickness="2" class="border-opacity-25"></v-divider>
                <p class="text-center ma-0"><strong>Departamento:</strong><br/>{{ profileMenu.userDepartment.value }}</p>
                <v-divider color="B9B9B9" :thickness="2" class="border-opacity-25"></v-divider>
                <p class="text-center ma-0"><strong>Rol:</strong> {{ profileMenu.userRole.value }}</p>
            </v-card>
        </v-menu>
        <v-divider vertical :thickness="2" class="border-opacity-100 my-5" color="black"></v-divider>
        <v-btn class="text-none" @click="Logout"><v-icon icon="mdi-logout"></v-icon><p class="ml-1">Cerrar Sesión</p></v-btn>
    </v-app-bar>
    <v-navigation-drawer v-model="verticalMenu" color="rgba(8, 9, 117, 0.8)">
        <p class="mt-5 ml-4 font-weight-light text-h6 vmElements">{{ profileMenu.userName.value }}</p>
        <v-divider class="border-opacity-100 mx-2 my-2" color="white"></v-divider>
        <v-list class="ml-3" nav>
            <v-list-group>
                <template v-slot:activator="{props}">
                    <v-list-item v-bind="props" class="px-0 pr-3 vmElements" rounded="shaped">
                        <v-icon icon="mdi-file-document-outline" class="d-inline"></v-icon><p class="d-inline ml-1 font-weight-bold">Pedidos</p>
                    </v-list-item>
                </template>
                <v-list-item color="white" class="vmElements font-weight-none" to="/cotizaciones/crear" rounded="shaped"><p class="ma-0">Crear</p></v-list-item>
                <v-list-item color="white" class="vmElements" to="/cotizaciones/pendiente" rounded="shaped"><p class="ma-0">Pendiente</p></v-list-item>
                <v-list-item color="white" class="vmElements" to="/cotizaciones/reporte" rounded="shaped"><p class="ma-0">Reporte</p></v-list-item>
            </v-list-group>           
        </v-list>
    </v-navigation-drawer>
    <v-dialog v-model="loadModal" persistent no-click-animation >
    <div class="text-center">
      <v-progress-circular color="primary" :size="72" :width="7" indeterminate></v-progress-circular>
    </div>
  </v-dialog>
</template>

<script setup lang="ts">
import { API_URL, LOGO_PATH, TAB_SITE_TITLE } from '@/config/env.config';
import { onBeforeMount, ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const verticalMenu = ref(false)
const loadModal = ref(false);

const profileMenu = {
    userName: ref("Usuario"),
    userRole: ref("Rol"),
    roleID: ref(""),
    userDepartment: ref("Departamento"),
}

async function Logout(){
    loadModal.value = true;
    await fetch(`${API_URL}/api/auth/signout`, {
        method:"POST",
        credentials: "include",
    }).then(res => {
        if (res.ok) return res.text();
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(async response => {
        await router.push("/login");
        router.go(0)
    }).catch(err =>{
        console.error(err)
    }).finally(() => { loadModal.value = false});
}

onBeforeMount(async ()=>{
    await fetch(`${API_URL}/api/auth/user-info`, {
        method:"GET",
        credentials: "include",
    }).then(res => {
        if (res.ok) return res.json();
        else if(res.status === 404) throw Error("No se encontró la información del usuario");
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(async response => {
        profileMenu.userName.value = response.nombre;
        profileMenu.userDepartment.value = response.nDepartamento;
        profileMenu.userRole.value = response.nRol;
        profileMenu.roleID.value = response.rol;
    }).catch(err =>{
        console.error(err);
    })
})
</script>
<style scoped>
.app-logo{
    height: 38px;
    width: auto;
    max-width: 130px;
    object-fit: contain;
}


@media(width <= 525px){
    .site-title{
        display: none
    }
}
.vmElements{
    color: white;
}
</style>