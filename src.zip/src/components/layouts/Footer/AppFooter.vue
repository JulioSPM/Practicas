<template>
    
    <footer v-if="$vuetify.display.mobile == false" class="d-flex justify-center align-center text-body-small" max-height="50" style="min-height: 50px;">
        <small>{{ footerText }}</small>
    </footer>
    <footer v-else height="80" class="d-flex align-center justify-center pa-3">
        <small class="text-body-small text-center">{{ footerText }}</small>
    </footer>
</template>

<script setup lang="ts">
import { COPYRIGHT_MSG } from '@/config/env.config';
import { ref } from 'vue';

const footerText = ref(COPYRIGHT_MSG);
</script>

<style scoped>
footer{
    background-color: #081375;
    color: #FFF;
}
</style>