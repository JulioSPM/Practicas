<template>
    <section class="mx-15 mt-8">
        <p class="text-headline-large titles">Pedidos</p>
        <div class="kpi-group mt-2 mb-5">
            <div>
                <v-card height="176" width="176" class="rounded-lg" hover>
                    <v-card-title class="text-body-medium font-weight-bold mt-2">Pedidos<br/>Creados</v-card-title>
                    <div style="padding-top: 3rem;" class="ml-3 d-flex">
                        <v-icon icon="mdi-file-document-plus-outline" size="30" color="#556B82"></v-icon>
                        <p class="font-weight-medium text-headline-small my-0 ml-2" style="color: #556B82;">{{ kpiGroup.createdQuot.value }}</p>
                    </div>
                </v-card>
            </div>
            <div class="opt2">
                <v-card height="176" width="176" class="rounded-lg" hover>
                    <v-card-title class="text-body-medium font-weight-bold mt-2">Pedidos<br/>Pendientes</v-card-title>
                    <div style="padding-top: 3rem;" class="ml-3 d-flex">
                        <v-icon icon="mdi-file-document-edit-outline" size="30" color="#556B82"></v-icon>
                        <p class="font-weight-medium text-headline-small my-0 ml-2" style="color: #556B82;">{{ kpiGroup.pendingQuot.value }}</p>
                    </div>
                </v-card>
            </div>
            <div class="opt3">
                <v-card height="176" width="176" class="rounded-lg" hover>
                    <v-card-title class="text-body-medium font-weight-bold mt-2">Pedidos<br/>Liberados</v-card-title>
                    <div style="padding-top: 3rem;" class="ml-3 d-flex">
                        <v-icon icon="mdi-file-sign" size="30" color="#556B82"></v-icon>
                        <p class="font-weight-medium text-headline-small my-0 ml-2" style="color: #556B82;">{{ kpiGroup.releasedQuot.value }}</p>
                    </div>
                </v-card>
            </div>
            <div class="opt4">
                <v-card height="176" width="176" class="rounded-lg" hover>
                    <v-card-title class="text-body-medium font-weight-bold mt-2">Pedidos<br/>Fallidos</v-card-title>
                    <div style="padding-top: 3rem;" class="ml-3 d-flex">
                        <v-icon icon="mdi-file-document-remove-outline" size="30" color="#556B82"></v-icon>
                        <p class="font-weight-medium text-headline-small my-0 ml-2" style="color: #556B82;">{{ kpiGroup.failedQuot.value }}</p>
                    </div>
                </v-card>
            </div>
        </div>
    </section>
</template>
<script setup lang="ts">
import type { KPIGroup } from '@/assets/ts/interfaces/kpi/kpi';
import { API_URL } from '@/config/env.config';
import { useHead } from '@unhead/vue';
import { onBeforeMount, ref, type Ref } from 'vue';

useHead({
    title: "Inicio"
})

const kpiGroup: KPIGroup = {
    createdQuot: ref(""),
    pendingQuot: ref(""),
    releasedQuot: ref(""),
    failedQuot: ref(""),
    isAdmin: ref(false)
}

onBeforeMount(async () =>{
    await fetch(`${API_URL}/api/home/check-kpi`, {
        method:"GET",
        credentials: "include",
    }).then(res => {
        if(res.ok) return res.json();
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`)
    }).then(response => {
        kpiGroup.createdQuot.value = response.kpiElements.cotizacionesCreadas;
        kpiGroup.pendingQuot.value = response.kpiElements.cotizacionesPendientes;
        kpiGroup.releasedQuot.value = response.kpiElements.cotizacionesLiberadas;
        kpiGroup.failedQuot.value = response.kpiElements.cotizacionesFallidas;

        if(response.role === "2") kpiGroup.isAdmin.value = true;
    }).catch(err => {
        console.error(err);
    })
})
</script>
<style scoped>
@media(width >= 800px){
    .kpi-group {
        display: grid;
        grid-template-columns: repeat(12, 1fr);
        grid-template-rows: repeat(1, 1fr);
        gap: 10px;
    }
}

@media(620px <= width < 800px){
    .kpi-group {
        display: grid;
        grid-template-columns: repeat(12, 1fr);
        grid-template-rows: repeat(3, 1fr);
        gap: 10px;
    }

    .opt3, .opt4 {
        grid-row-start: 2;
    }
}

@media(width < 620px){
    .kpi-group {
        display: grid;
        grid-template-columns: repeat(1, 1fr);
        grid-template-rows: repeat(4, 1fr);
        gap: 10px;
    }
    .opt2 {
        grid-row-start: 2;
    }

    .opt3 {
        grid-row-start: 3;
    }
    .opt4 {
        grid-row-start: 4;
    }
}

.v-card:hover{
    border: 1px solid #7E8FA1;
    cursor: default;
}

.titles{
    color:#1D2D3E;
}
</style>