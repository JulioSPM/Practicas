<template>
    <v-menu :close-on-content-click="false" transition="slide-y-transition" v-model="closePicker">
        <template v-slot:activator="{props}">
            <v-text-field append-inner-icon="mdi-calendar-month" variant="outlined" :label="fieldLabel" placeholder="aaaa/mm/dd" persistent-placeholder readonly v-model="model" v-bind="props" density="compact" hide-details="auto" class="input" :name="name">
            </v-text-field>
        </template>
        <v-date-picker min-width="300" max-width="330" show-adjacent-months v-model="date" v-on:update:model-value="DateRetrieval" hide-header>
        </v-date-picker>
    </v-menu>
</template>
<script setup lang="ts">
import { useDate, type DateInstance } from 'vuetify';
import {ref} from 'vue';

const model = defineModel()
const adapter: DateInstance = useDate();

let date= ref();
let closePicker = ref(false);

const props = defineProps({
    fieldLabel: {
        type: String,
        required: true
    },
    name:{
        type: String,
        required: false
    }
})

function DateRetrieval(){
    const options = { year: 'numeric', month: '2-digit', day: '2-digit'};
    
    //@ts-ignore
    const f = new Intl.DateTimeFormat("es-mx", options)
    let parts = f.formatToParts(adapter.toJsDate(date.value).getTime())
    //@ts-ignore
    const year = parts.find(part => part.type === 'year').value;
    //@ts-ignore
    const month = parts.find(part => part.type === 'month').value;
    //@ts-ignore
    const day = parts.find(part => part.type === 'day').value;
    date.value = `${year}/${month}/${day}`
    model.value = date.value;
    closePicker.value = false;
}

</script>
<style scoped src="@/scss/input.scss"></style>
<style scoped>
</style>