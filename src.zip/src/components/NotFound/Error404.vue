<template>
    <section class="d-flex justify-center align-center">
        <div class="">
            <div class="d-flex justify-center">
                <v-icon icon="mdi-alert-outline" size="150"></v-icon>
            </div>
            <p class="text-h4 font-weight-bold text-center">Error 404</p>
            <p class="text-subtitle-1 font-weight-bold text-center">La página ingresada no existe</p>
            <!--
            <div class="d-flex justify-center">
                <v-btn prepend-icon="mdi-home-outline" to="/" class="mt-7 text-none" color="#2B4FC4">Regresar a Inicio</v-btn>
            </div>-->
        </div>
    </section>
</template>
<script setup lang="ts">
import { useHead } from '@unhead/vue';

useHead({
    title: "Página no Encontrada"
})
</script>
<style scoped>
section{
    height: 100%
}
</style>