<template>
    <section>
        <v-breadcrumbs :items="paths.GetItems()" class="ml-3 text-body-small pb-0 pt-2">
            <template v-slot:prepend>
                <v-icon icon="mdi-home" size="small"></v-icon>
            </template>
        </v-breadcrumbs>
        <p class="text-headline-small font-weight-medium ml-6">Reporte de Pedidos</p>
    </section>
    <section>
        <v-form @submit.prevent="SearchData">
            <v-container class="ma-0 px-6 pb-0" fluid>
                <v-row density="comfortable">
                    <v-col xs="12" md="2" cols="12">
                        <DatePicker field-label="Fecha Inicial" name="start_date" v-model="initialDate"/>
                    </v-col>
                    <v-col xs="12" md="2" cols="12">
                        <DatePicker field-label="Fecha Final" name="end_date" v-model="endDate"/>
                    </v-col>
                    <v-col xs="12" md="2" cols="12">
                        <v-select v-model="sapStatusField" variant="outlined" density="compact" label="Estatus SAP" name="status" hide-details="auto" class="input" :items="sapStatusOptions" multiple clearable></v-select>
                    </v-col>
                    <v-col xs="12" md="2" cols="12">
                        <v-switch v-model="statusField" variant="outlined" density="compact" label="Solo Subido a SAP" hide-details="auto" color="primary" @update:model-value="console.log(statusField)"></v-switch>
                    </v-col>
                    <v-col xs="12" md="4" cols="12">
                        <v-btn prepend-icon="mdi-magnify" color="#0AB39C" class="text-none" size="small" type="submit"><small>Buscar</small></v-btn>
                    </v-col>
                </v-row>
                <v-divider opacity="0.7" class="my-2"></v-divider>
                <v-row density="comfortable">
                    <v-col xs="12" md="3" cols="12">
                        <v-text-field label="Filtrar por Proyecto" type="text" variant="outlined" density="compact" hide-details="auto" class="input" name="project" v-model="cotSearchName" maxlength="30"></v-text-field>
                    </v-col>
                </v-row>
            </v-container>
        </v-form>
    </section>
    <v-divider class="border-opacity-100 mx-2 mb-2 mt-2"></v-divider>
    <section>
        <v-card class="mx-6 pa-2 mt-2">
            <v-data-table :headers="activeHeaders" striped="odd" :items="tableData" :search="cotSearchName" :filter-keys="['project_name']" height="25rem" density="compact" items-per-page-text="Elementos por página"  no-data-text="No se encontraron pedidos"  hover>
                <template v-slot:item.uploaded_sap="{ item }">
                    <v-chip v-if="item.uploaded_sap == true" density="compact" size="small" color="#0AB39C" variant="text">
                        <v-icon icon="mdi-check"></v-icon>
                    </v-chip>
                    <v-chip v-else density="compact" size="small" color="#D9534F" variant="text">
                        <v-icon icon="mdi-close"></v-icon>
                    </v-chip>
                </template>
                <template v-slot:item.check_detail="{ item }">
                    <v-btn prepend-icon="mdi-arrow-right" color="#0AB39C" size="small" class="text-none" variant="text" :to="`/cotizaciones/${item.docNum}`">Ver Detalle</v-btn>
                </template>
                <template v-slot:item.actions="{ item }">
                    <div class="action-buttons">
                        <div class="action-1">
                            <v-btn prepend-icon="mdi-pencil-outline" color="#F0AD4E" size="small" class="text-none" :to="`/cotizaciones/editar/${item.docNum}`"><small>Editar</small></v-btn>
                        </div>
                    </div>
                </template>
            </v-data-table>
        </v-card>
    </section>
    <v-dialog v-model="loadModal" persistent no-click-animation>
        <div class="text-center">
        <v-progress-circular color="primary" :size="72" :width="7" indeterminate></v-progress-circular>
        </div>
    </v-dialog>
</template>
<script setup lang="ts">
import { useHead } from '@unhead/vue';
import { useRoute, useRouter, type RouteLocationNormalizedLoadedGeneric, type Router } from 'vue-router';
import { computed, onBeforeMount, reactive, ref, type ComputedRef, type Ref } from 'vue';
import BreadCrumb from '@/assets/ts/classes/pages/Breadcrumb';
import DatePicker from '@/components/custom/fields/DatePicker.vue';
import { POSITION, useToast } from "vue-toastification";
import { API_URL } from '@/config/env.config';

useHead({
    title: "Reporte de Solicitudes de Compra"
})

//Route and router variables for going to other pages of the website or seing the actual path
const route: RouteLocationNormalizedLoadedGeneric = useRoute();
const router: Router = useRouter();
const role: Ref<string> = ref("");

const toast = useToast(); //toast variable for creating toast notifications

const paths: BreadCrumb = new BreadCrumb();

//Section with the constants that will store the reactive values of the fields in the header.
const initialDate: Ref<string> = ref("");
const endDate: Ref<string> = ref("");
const cotSearchName: Ref<string> = ref("");

const sapStatusOptions: {title: string, value: string}[]= [
    { title: 'Abierto', value: 'open' },
    { title: 'Cerrado', value: 'closed' },
];
const statusField: Ref<boolean> = ref(false);
const sapStatusField: Ref<string[]> = ref([]);

const tableHeaders: Array<any> = [
    { width: 100, title: '#', key: 'table_id', align: 'start', sortable: true, condition: () => true },
    { width: 200, title: 'ID Doc', key: 'docNum', align: 'start', sortable: true, condition: () => false },
    { width: 500, title: 'Proyecto', key: 'project_name', align: 'start', sortable: true, condition: () => true },
    { width: 100, title: 'Fecha de Contabilización', key: 'doc_date', align: 'start', sortable: true, condition: () => true },
    { width: 300, title: 'Usuario', key: 'user', align: 'start', sortable: true, condition: () => role.value === "2"},
    { width: 300, title: 'Total', key: 'total', align: 'start', sortable: true, condition: () => true },
    { width: 200, title: 'Subido a SAP', key: 'uploaded_sap', align: 'start', sortable: false, condition: () => true},
    { width: 200, title: 'Estatus en SAP', key: 'status_sap', align: 'start', sortable: false, condition: () => true},
    { width: 300, title: 'Detalle', key: 'check_detail', align: 'start', sortable: false, condition: () => true },
    { width: 300, title: 'Acciones', key: 'actions', align: 'start', sortable: false, condition: () => true }

];

const activeHeaders: ComputedRef<any[]> = computed(() => {
    return tableHeaders.filter(col => col.condition());
});
const loadModal: Ref<boolean> = ref(false);

const tableData: Ref<Array<{table_id: string, docNum: string, project_name: string, doc_date: string, user?: string, total: string, uploaded_sap: boolean, status_sap: string}>> = ref([])

async function SearchData(){
    if(initialDate.value == ""){
        toast.warning("Se debe tener una fecha inicial", {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    }
    else{
        loadModal.value = true;
        tableData.value.length = 0;

        let date1: string | null = null;
        let date2: string | null = null;
        let sapStatusList: string | null = null;

        const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
        const f = new Intl.DateTimeFormat("es-mx", options as any)

        if(initialDate.value != "") date1 = initialDate.value;
        else date1 = "";

        if(endDate.value == ""){
            let temp: string[] = f.format(Date.now()).split("/");
            date2 = `${temp[2]}/${temp[1]}/${temp[0]}`;
        }
        else date2 = endDate.value;

        if(sapStatusField.value.length > 0) sapStatusList = sapStatusField.value.join(", ");
        
        const params = new URLSearchParams();
        params.append("initialDate", date1);
        params.append("endDate", date2);
        params.append("uploaded", statusField.value.toString());
        params.append("sapStatus", sapStatusList == null ? "" : sapStatusList as string)
       
        await fetch(`${API_URL}/api/cotizaciones/report/filter?${params}`, {
            method:"GET",
            credentials: "include",
            headers: {"Content-Type": 'application/x-www-form-urlencoded'}
        }).then(async res => {
            if(res.ok) return res.json();
            else if(res.status == 500){
                const errMsg = await res.text();
                const error = new Error(errMsg);
                error.name = "ServerError";

                throw error;
            }
            else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
        }).then(response => {
            let salesQuotations: Array<{docNum: string, project: string, docDate: string, user?: string, total: number, uploadedSAP: boolean, statusSAP: string}> = response.data as Array<{docNum: string, project: string, docDate: string, user?: string, total: number, uploadedSAP: boolean, statusSAP: string}>
            salesQuotations.forEach((quotation, index) =>{
                if(role.value === "2"){
                    tableData.value.push({
                        table_id: (index + 1).toString(),
                        docNum: quotation.docNum as string,
                        project_name: quotation.project,
                        doc_date: quotation.docDate,
                        user: quotation.user,
                        total: `$${quotation.total}`,
                        uploaded_sap: quotation.uploadedSAP,
                        status_sap: quotation.statusSAP
                    });
                }
                else{
                    tableData.value.push({
                        table_id: (index + 1).toString(),
                        docNum: quotation.docNum as string,
                        project_name: quotation.project,
                        doc_date: quotation.docDate,
                        total: `$${quotation.total}`,
                        uploaded_sap: quotation.uploadedSAP,
                        status_sap: quotation.statusSAP
                    });
                }
            });
            
        }).catch(err => {
            let msg = "";
            if(err.name === "ServerError"){
                msg = err.message;
                console.error(msg);
            }
            else{
                msg = `Ha ocurrido un error al realizar la búsqueda de pedidos. ${err}`;
                console.error(msg);
            }

            toast.error(msg, {
                position: POSITION.BOTTOM_CENTER,
                timeout: 2500,
                pauseOnFocusLoss: false,
                pauseOnHover: false,
                hideProgressBar: true,
                closeButton: false,
                icon: false
            });
        }).finally(() => {loadModal.value = false;});
    }
}

onBeforeMount(async () => {
    route.fullPath.split("/").slice(1).forEach((path) => {
        if(path === "cotizaciones") paths.SetItems({title: "Pedidos", disabled: true, href: ""});
        else paths.SetItems({title: path.charAt(0).toUpperCase() + path.slice(1), disabled: false, href:path});
    })

    await fetch(`${API_URL}/api/auth/user-info`, {
        method:"GET",
        credentials: "include",
    }).then(res => {
        if (res.ok) return res.json();
        else if(res.status === 401 || res.status === 404) throw Error("No se encontró una sesión activa")
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(async response => {
        role.value = response.rol;
    }).catch(err =>{
        console.error(err);
    })

    await fetch(`${API_URL}/api/cotizaciones/report`, {
        method:"GET",
        credentials: "include"
    }).then(async res =>{
        if(res.ok) return res.json();
        else if(res.status == 500){
            const errMsg = await res.text();
            const error = new Error(errMsg);
            error.name = "ServerError";

            throw error;
        }
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(response =>{
        const salesQuotations: Array<{docNum: string, project: string, docDate: string, user?: string, total: number, uploadedSAP: boolean, statusSAP: string}> = response.data as Array<{docNum: string, project: string, docDate: string, user?: string, total: number, uploadedSAP: boolean, statusSAP: string}>
        
        salesQuotations.forEach((quotation, index) =>{
            if(role.value === "2"){
                tableData.value.push({
                    table_id: (index + 1).toString(),
                    docNum: quotation.docNum,
                    project_name: quotation.project,
                    doc_date: quotation.docDate,
                    user: quotation.user,
                    total: `$${quotation.total}`,
                    uploaded_sap: quotation.uploadedSAP,
                    status_sap: quotation.statusSAP
                });
            }
            else{
                tableData.value.push({
                    table_id: (index + 1).toString(),
                    docNum: quotation.docNum,
                    project_name: quotation.project,
                    doc_date: quotation.docDate,
                    total: `$${quotation.total}`,
                    uploaded_sap: quotation.uploadedSAP,
                    status_sap: quotation.statusSAP
                });
            }
        });
    }).catch(err =>{
        let msg = "";
        if(err.name === "ServerError"){
            msg = err.message;
            console.error(msg);
        }
        else{
            msg = `Ha ocurrido un error al realizar la búsqueda de pedidos. ${err}`;
            console.error(msg);
        }

        toast.error(msg, {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    });
})
</script>
<style scoped src="@/scss/input.scss"></style>
<style scoped>
.kpi-group {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    grid-template-rows: repeat(1, 1fr);
    gap: 10px;
}

.action-buttons{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: repeat(1, 1fr);
    gap: 5px;
}
</style>