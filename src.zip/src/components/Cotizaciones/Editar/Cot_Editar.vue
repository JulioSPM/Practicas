<template>
    <section>
        <v-breadcrumbs :items="paths.GetItems()" class="ml-3 text-body-small pb-0 pt-2">
            <template v-slot:prepend>
                <v-icon icon="mdi-home" size="small"></v-icon>
            </template>
        </v-breadcrumbs>
        <p class="text-headline-small font-weight-medium ml-6 my-1">Editar Pedido</p>
    </section>
    <section>
        <v-form ref="salesQuotationForm" @submit.prevent="EditRequest">
            <section>
                <v-container class="ma-0 px-6 pb-0" fluid>
                    <v-row>
                        <v-col xs="12" md="2" cols="12">
                            <v-autocomplete label="*Cliente" item-title="title" item-value="value" :filter-keys="['title', 'value']" v-model="clientVal" v-model:search="clientSearchVal" :items="clientList" variant="outlined" density="compact" hide-details="auto" class="input" menu-icon="" persistent-placeholder @update:search="SearchClient" @update:model-value="OnClientSelected" auto-select-first :loading="loadingClient" :menu-props="{ maxHeight: 320 }" no-data-text="No se encontraron clientes" name="client"></v-autocomplete>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <v-select label="*Emp. de Ventas" item-title="title" item-value="value" v-model="retailEmployeeVal" :items="retailEmployeeList" variant="outlined" density="compact" hide-details="auto" class="input" persistent-placeholder auto-select-first name="retail_employee"></v-select>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <DatePicker field-label="*Fecha Contabilización" v-model="docDateVal" name="doc_date"/>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <DatePicker field-label="*Válido Hasta" v-model="docDueDateVal" name="doc_due_date"/>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <DatePicker field-label="*Fecha Documento" v-model="taxDateVal" name="tax_date"/>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <v-text-field label="Referencia" type="text" variant="outlined" density="compact" hide-details="auto" class="input" name="reference" v-model="reference" maxlength="200"></v-text-field>
                        </v-col>
                    </v-row>
                    <v-row class="mt-4">
                        <v-col xs="12" md="2" cols="12">
                            <v-text-field label="*Proyecto" type="text" variant="outlined" density="compact" hide-details="auto" class="input" name="project" v-model="project" maxlength="30"></v-text-field>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <v-select label="*Tipo de Proyecto" item-title="title" item-value="value" :items="projectTypeList" variant="outlined" density="compact" hide-details="auto" class="input" name="project_type" v-model="projectType"></v-select>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <v-select label="*Pre/Pedido" item-title="title" item-value="value" :items="quotationTypeList" variant="outlined" density="compact" hide-details="auto" class="input" name="quotation_type" v-model="quotationType"></v-select>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <v-text-field label="*% de pago anticipo" type="number" min="0" max="100" step="0.01" variant="outlined" density="compact" hide-details="auto" class="input" name="prcnt_pay_advance" v-model="prcntPayAdvance"></v-text-field>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <v-text-field label="*% de pago proyecto arranque" type="number" min="0" max="100" step="0.01" variant="outlined" density="compact" hide-details="auto" class="input" name="prcnt_project_started" v-model="prcntProjectStarted"></v-text-field>
                        </v-col>
                        <v-col xs="12" md="2" cols="12">
                            <v-text-field label="Comentarios" no-resize variant="outlined" density="compact" hide-details="auto" class="input" name="comments" v-model="comments" maxlength="254"></v-text-field>
                        </v-col>
                    </v-row>
                </v-container>
            </section>

            <v-divider class="border-opacity-100 mx-2 mb-2 mt-2"></v-divider>
            <section>
                <div class="d-flex">
                    <p class="text-body-large font-weight-semibold my-1 ml-6">Artículos</p>
                    <div class="ml-1">
                        <v-tooltip>
                            <template v-slot:activator="{ props }">
                                <v-icon icon="mdi-help-circle" v-bind="props" size="x-small"></v-icon>
                                
                            </template>
                            <div class="d-flex ma-0">
                                <v-hotkey keys="shift+enter" variant="elevated" platform="auto" />
                                <p class="font-size-small ml-2"><small>Añadir Línea</small></p>
                            </div>
                            <div class="d-flex">
                                <v-hotkey keys="shift+backspace/shift+delete" variant="elevated" platform="auto" />
                                <p class="font-size-small ml-2"><small>Eliminar Última Línea</small></p>
                            </div>
                        </v-tooltip>
                    </div>
                </div>
                
                <div class="table-setup">
                    <div>
                        <v-btn class="mx-6 mt-3 text-none opt2" prepend-icon="mdi-plus" color="#2B4FC4" @click="AddRow" size="small"><small>Añadir</small></v-btn>
                    </div>
                </div>
                
                <v-card class="mx-6 pa-2 mt-2" color="#D9D9D9">
                    <v-table striped="odd" height="21rem" fixed-header hide-default-footer hover ref="goodTable" density="compact">
                        <thead>
                            <tr>
                                <template v-for="header in headersArticle">
                                    <th v-if="header.enabled" :class="`text-${header.align} header-content`" :key="header.key" :style="{width: columnWidths[header.key] + 'px', minWidth: columnWidths[header.key] + 'px', maxWidth: columnWidths[header.key] + 'px'}">
                                        <div class="header-inner">
                                            <div class="header-text" :title="header.title">
                                                <v-tooltip :text="`${header.title}`" location="top" :open-on-hover="false" open-on-click>
                                                    <template v-slot:activator="{ props }">
                                                        <p v-bind="props">{{ header.title }}</p>
                                                    </template>
                                                </v-tooltip>
                                            </div>
                                            <div class="resize-handle" @mousedown="startResize($event,header.key)"></div>
                                        </div>
                                    </th>
                                </template>
                            </tr>
                        </thead>
                        <tbody>
                            <template v-if="articles.Length() == 0">
                                <tr>
                                    <td :colspan="headersArticle.length" class="text-center">No hay ningún artículo añadido</td>
                                </tr>
                            </template>
                            <template v-else>
                                <tr v-for="(article, index) in articles.GetRows()" :key="`article-${index}`">
                                    <td >{{ index + 1 }}</td>
                                    <td>
                                        <v-autocomplete v-model="article.article.value" v-model:search="article.articleSearchVal.value" :items="article.articleSearchElements.value" item-title="title" item-value="value" :filter-keys="['title', 'value']" density="compact" :tile="true" menu-icon="" hide-details="auto" class="inputTableRow" style="width: 100%" :ref="`articlesRef-${index}`" @update:search="SearchArticle($event, article.articleSearchElements.value, article.loadingSearchArtField.value, article.article.value)" @update:model-value="SearchArticleDetails($event, $refs[`articlesRef-${index}`])" auto-select-first :loading="article.loadingSearchArtField.value" :menu-props="{ maxHeight: 320 }" no-data-text="No se encontraron artículos"></v-autocomplete>
                                    </td>
                                    <td class="article-description-cell">
                                        <span class="article-description-text" :title="article.description.value">
                                            {{ article.description.value }}
                                        </span>
                                    </td>
                                    <td><v-text-field type="number" density="compact" :tile="true" v-model="article.amount.value" hide-details="auto" class="inputTableRow" style="width: 100%" :ref="`amount-${index}`" @update:model-value="UpdateTotal($refs[`amount-${index}`])"></v-text-field></td>
                                    <td><v-text-field type="number" density="compact" :tile="true" v-model="article.unitPrice.value" hide-details="auto" class="inputTableRow" style="width: 100%" prefix="$" :ref="`unitPrice-${index}`" @update:model-value="UpdateTotal($refs[`unitPrice-${index}`])"></v-text-field></td>
                                    <td><v-text-field type="number" density="compact" :tile="true" v-model="article.prcntDiscount.value" hide-details="auto" class="inputTableRow" style="width: 100%" suffix="%" :ref="`prcntDiscount-${index}`" @update:model-value="UpdateTotal($refs[`prcntDiscount-${index}`])"></v-text-field></td>
                                    <td><v-select style="width: 100%" density="compact" hide-details="auto" :tile="true" v-model="article.impuesto.value" class="inputTableRow" :items="taxList" :item-props="true"></v-select></td>
                                    <td>$ {{ article.lineTotal.value.toFixed(2) }}</td>
                                    <td v-if="dimensionsElements.get('dim1')!.enabled.value"><v-select style="width: 100%" density="compact" hide-details="auto" :tile="true" v-model="article.dim1.value" class="inputTableRow" :items="dimensionsElements.get('dim1')!.values.value" :item-props="true"></v-select></td>
                                    <td v-if="dimensionsElements.get('dim2')!.enabled.value"><v-select style="width: 100%" density="compact" hide-details="auto" :tile="true" v-model="article.dim2.value" class="inputTableRow" :items="dimensionsElements.get('dim2')!.values.value" :item-props="true"></v-select></td>
                                    <td v-if="dimensionsElements.get('dim3')!.enabled.value"><v-select style="width: 100%" density="compact" hide-details="auto" :tile="true" v-model="article.dim3.value" class="inputTableRow" :items="dimensionsElements.get('dim3')!.values.value" :item-props="true"></v-select></td>
                                    <td v-if="dimensionsElements.get('dim4')!.enabled.value"><v-select style="width: 100%" density="compact" hide-details="auto" :tile="true" v-model="article.dim4.value" class="inputTableRow" :items="dimensionsElements.get('dim4')!.values.value" :item-props="true"></v-select></td>
                                    <td v-if="dimensionsElements.get('dim5')!.enabled.value"><v-select style="width: 100%" density="compact" hide-details="auto" :tile="true" v-model="article.dim5.value" class="inputTableRow" :items="dimensionsElements.get('dim5')!.values.value" :item-props="true"></v-select></td>
                                    <td>
                                        <div class="d-flex justify-center align-center">
                                            <v-btn size="small" variant="text" color="#D9534F" @click="DeleteRow($event)">
                                                <v-icon icon="mdi-minus"></v-icon>
                                                <p class="text-none pl-2">Eliminar</p>
                                            </v-btn>
                                        </div>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                        <tfoot v-if="articles.Length() > 0">
                            <tr>
                                <td :colspan="headersArticle.length" >Total: ${{ tableTotal.toFixed(2) }}</td>
                            </tr>
                        </tfoot>
                    </v-table>
                </v-card>
            </section>
            <section class="my-3 mx-6 btn-group">
                <div>
                    <v-dialog min-width="300" max-width="400">
                        <template v-slot:activator="{ props: activatorProps }">
                            <v-btn color="#0AB39C" class="text-none" width="181.73" v-bind="activatorProps">Editar Pedido</v-btn>
                        </template>
                        <template v-slot:default="{ isActive }">
                            <v-card>
                                <v-card-title class="font-weight-bold">Editar Pedido</v-card-title>
                                <v-card-text class="text-center">
                                    ¿Desea editar el pedido?
                                </v-card-text>
                                <v-card-actions>
                                    <v-btn color="#0AB39C" class="text-none" @click="ConfirmEdit(isActive)">Confirmar</v-btn>
                                    <v-btn color="#D9534F" @click="isActive.value = false" class="text-none">Regresar</v-btn>
                                </v-card-actions>
                            </v-card>
                        </template>
                    </v-dialog>
                    
                </div>
                <div class="opt2">
                    <v-dialog min-width="300" max-width="400">
                        <template v-slot:activator="{ props: activatorProps }">
                            <v-btn color="#D9534F" class="text-none" width="181.73" v-bind="activatorProps">Cancelar</v-btn>
                        </template>
                        <template v-slot:default="{ isActive }">
                            <v-card>
                                <v-card-title class="font-weight-bold">Confirmar acción</v-card-title>
                                <v-card-text class="text-center">
                                    ¿Está seguro que desea cancelar la operación? Se perderá toda la información.
                                </v-card-text>
                                <v-card-actions>
                                    <v-btn color="#0AB39C" class="text-none" to="/">Confirmar</v-btn>
                                    <v-btn color="#D9534F" @click="isActive.value = false" class="text-none">Regresar</v-btn>
                                </v-card-actions>
                            </v-card>
                        </template>
                    </v-dialog>
                </div>
            </section>
        </v-form>
    </section>
    <v-dialog v-model="loadModal" persistent no-click-animation>
        <div class="text-center">
        <v-progress-circular color="primary" :size="72" :width="7" indeterminate></v-progress-circular>
        </div>
    </v-dialog>
</template>

<script setup lang="ts">
import { useHead } from '@unhead/vue';
import { useRoute, useRouter, type RouteLocationNormalizedLoadedGeneric, type Router } from 'vue-router';
import DatePicker from '@/components/custom/fields/DatePicker.vue';
import { onBeforeMount, onMounted, onUnmounted, reactive, ref, type Ref } from 'vue';
import BreadCrumb from '@/assets/ts/classes/pages/Breadcrumb';
import type { DocTypeHeaders } from '@/assets/ts/interfaces/documentType/interfaces';
import QuotationArticle from '@/assets/ts/classes/documentType/QuotationArticle';
import { useTemplateRef } from 'vue';
import type { DimensionDescription, ERPSalesQuotationArticle, SalesQuotation, SelectField, SelectField2 } from '@/assets/ts/interfaces/pages/interfaces';
import { POSITION, useToast } from "vue-toastification";
import { API_URL, DEFAULT_SALESQUOT_TAX_CODE } from '@/config/env.config';

useHead({
    title: "Editar Pedido"
})

let body: SalesQuotation | null = null;

//Route and router variables for going to other pages of the website or seing the actual path
const route: RouteLocationNormalizedLoadedGeneric = useRoute();
const router: Router = useRouter();

const toast = useToast(); //toast variable for creating toast notifications

const form = useTemplateRef("salesQuotationForm");

//Area of variables for loading ref components
const loadModal: Ref<boolean> = ref(false);
const loadingClient:Ref<boolean> = ref(false);

const docNum = route.params.id;

//Area of header field values
const docDateVal: Ref<string> = ref("");
const docDueDateVal: Ref<string> = ref("");
const taxDateVal: Ref<string> = ref("");

const clientList: Ref<SelectField[]> = ref([]); //List where all the found clients will be stored
const clientVal: Ref<string | null> = ref(null); //Stores the value of the client field when searching
const clientSearchVal: Ref<string> = ref(""); //Stores the value of the client field when selecting an option

// Evita que búsquedas anteriores vuelvan a abrir el desplegable después de seleccionar.
let clientSearchTimeout: ReturnType<typeof setTimeout> | null = null;
let clientSearchController: AbortController | null = null;

const retailEmployeeList: Ref<SelectField[]> = ref([]); //List where all the found sellers will be stored
const retailEmployeeVal: Ref<string | null> = ref(null); //Stores the value of the seller field

const project: Ref<string> = ref("");
const prcntPayAdvance: Ref<string> = ref("");
const prcntProjectStarted: Ref<string> = ref("");
const reference: Ref<string> = ref("");

const projectType: Ref<string | null> = ref(null);
const projectTypeList: Ref<SelectField[]> = ref([
    {title: "Control de Accesos", value: "1"}, 
    {title: "Estacionamiento Digital", value: "2"},
    {title: "Infracción Digital", value: "3"},
    {title: "Equipo", value: "4"},
    {title: "Control de Accesos Escolar", value: "5"},
    {title: "Parquímetro", value: "6"},
    {title: "Valet Parking", value: "7"},
    {title: "Otros Servicios", value: "8"},
    {title: "Mixto", value: "9"}
]);

const quotationType: Ref<string | null> = ref(null);
const quotationTypeList: Ref<SelectField[]> = ref([{title: "PREPEDIDO", value: "Pre"}, {title: "PEDIDO", value: "Cotizacion"}]);

const comments: Ref<string> = ref("");
//const attachments: Ref<File[]> = ref([]);

//Area of references to both the article and service table respectively so it can be easy to update the elements at it inside of a function (by forcing the update)
const tableRef = useTemplateRef("goodTable");

const paths: BreadCrumb = new BreadCrumb(); //Variable que nos va a permitir definir los elementos del componente breadcrumb

//Area of variables that represent the group of objects of type articles and services respectively, including all its methods
const articles: QuotationArticle = new QuotationArticle();

const tableTotal: Ref<number> = ref(0.00); //For manipulating the tableTotal when get to be needed
    
const taxList: SelectField2[] = [];

let listadoDimensiones: string[] = [];

let dimensionsElements: Map<string, DimensionDescription> = new Map<string, DimensionDescription>();

dimensionsElements.set("dim1", {enabled: ref(true), values: ref([])});
dimensionsElements.set("dim2", {enabled: ref(true), values: ref([])});
dimensionsElements.set("dim3", {enabled: ref(true), values: ref([])});
dimensionsElements.set("dim4", {enabled: ref(true), values: ref([])});
dimensionsElements.set("dim5", {enabled: ref(true), values: ref([])});

let columnWidths: {[key: string]: number} = reactive({});
const isResizing: Ref<boolean> = ref(false);
const resizingColumn: Ref<string | null> = ref(null);
const startX = ref(0);
const startWidth = ref(0);

const headersArticle: DocTypeHeaders[] = [
    {title: "#", key: "art-tableID", align: "center", width: 30, enabled: true},
    {title: "*Articulo", key: "art-article", align: "center", width: 260, enabled: true},
    {title: "Nombre Cotizador", key: "art-desc", align: "center", width: 260, enabled: true},
    {title: "*Cantidad", key: "art-amount", align: "center", width: 110, enabled: true},
    {title: "*Precio Unitario", key: "art-unitPrice", align: "center", width: 140, enabled: true},
    {title: "% de descuento", key: "art-prcntDiscount", align: "center", width: 140, enabled: true},
    {title: "*Indicador de impuestos", key: "art-taxCode", align: "center", width: 140, enabled: true},
    {title: "Total", key: "line-total", align: "center", width: 110, enabled: true},
    {title: "Centro de Costos 1", key: "art-dim1", align: "center", width: 100, enabled: true},
    {title: "Centro de Costos 2", key: "art-dim2", align: "center", width: 100, enabled: true},
    {title: "Centro de Costos 3", key: "art-dim3", align: "center", width: 100, enabled: true},
    {title: "Centro de Costos 4", key: "art-dim4", align: "center", width: 100, enabled: true},
    {title: "Centro de Costos 5", key: "art-dim5", align: "center", width: 100, enabled: true},
    {title: "Acción", key: "art-options", align: "center", width: 80, enabled: true}
]

async function SearchArticle(event: any, erpArticles: SelectField[], loader: boolean, fieldValue: string | null){
    if(event.trim() === "") return;
    const selectedElementTitle = erpArticles.find(x => x.value == fieldValue)?.title;
    if(selectedElementTitle == event) return;

    loader = true;
    erpArticles.length = 0;

    const params = new URLSearchParams();
    params.append("key", event);
    params.append("type", "quotation");

    await fetch(`${API_URL}/api/articulos?${params}`, {
        method:"GET",
        credentials: "include",
        headers: {"Content-Type": 'application/x-www-form-urlencoded'},
    }).then(res =>{
        if(res.ok) return res.json();
        else throw Error(`Ha ocurrido un error al buscar artículos. Código de Estado: ${res.status}`);
    }).then(response =>{
        const articleList = response.data as Array<{codigo: string, nombre: string}>;

        for(let art = 0; art < articleList.length; art++){
            const codigo = String(articleList[art].codigo ?? "").trim();
            const nombre = String(articleList[art].nombre ?? "").trim();

            if(codigo === "") continue;

            let value: SelectField = {
                title: `${codigo} - ${nombre || "Sin nombre"}`,
                value: codigo
            };
            erpArticles.push(value);
        }
    }).catch(err =>{
        console.error(`${err}`);
    }).finally(() => {loader = false})
}
async function SearchArticleDetails(event: string | null, element: any){
    let component = element[0].$el as HTMLElement;
    const rowIndex: number = parseInt(component.parentNode!.parentNode!.children[0].textContent) - 1;
    if(event != null){
        loadModal.value = true

        await fetch(`${API_URL}/api/articulos/${event}`, {
            method:"GET",
            credentials: "include"
        }).then(res =>{
            if(res.ok) return res.json();
            else throw Error(`Ha ocurrido un error al buscar el artículo. ${res.status}`);
        }).then(response =>{
            const row = articles.GetRow(rowIndex);
            row.description.value = response.nombre
            row.unitPrice.value = response.precioUnitario;

            UpdateTotal(element);
        }).catch(err =>{
            console.error(`An error has just occurred: ${err}`);
        }).finally(()=>{loadModal.value = false;})
    }
}

function OnClientSelected(value: string | null){
    if(clientSearchTimeout !== null){
        clearTimeout(clientSearchTimeout);
        clientSearchTimeout = null;
    }

    clientSearchController?.abort();

    if(value === null) return;

    const selectedClient = clientList.value.find(x => x.value === value);
    if(selectedClient !== undefined){
        clientSearchVal.value = selectedClient.title;
    }
}

function SearchClient(searchValue: string | null){
    const searchTerm = (searchValue ?? "").trim();

    if(clientSearchTimeout !== null){
        clearTimeout(clientSearchTimeout);
        clientSearchTimeout = null;
    }

    if(searchTerm === ""){
        clientList.value = [];
        return;
    }

    const selectedClient = clientList.value.find(x => x.value === clientVal.value);
    if(clientVal.value !== null && selectedClient?.title === searchTerm) return;

    clientSearchTimeout = setTimeout(() => {
        LoadClients(searchTerm);
    }, 300);
}

async function LoadClients(searchTerm: string){
    clientSearchController?.abort();

    const controller = new AbortController();
    clientSearchController = controller;
    loadingClient.value = true;

    const params = new URLSearchParams();
    params.append("key", searchTerm);
    params.append("type", "quotation");

    try{
        const res = await fetch(`${API_URL}/api/bp?${params}`, {
            method: "GET",
            credentials: "include",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            signal: controller.signal,
        });

        if(!res.ok){
            throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
        }

        const response = await res.json();
        const supplierList = response.data as Array<{codigo: string, nombre: string}>;
        const uniqueClients = new Map<string, SelectField>();

        supplierList.forEach(el => {
            const codigo = String(el.codigo ?? "").trim();
            const nombre = String(el.nombre ?? "").trim();

            if(codigo === "" || uniqueClients.has(codigo)) return;

            uniqueClients.set(codigo, {
                title: `${codigo} - ${nombre || "Sin nombre"}`,
                value: codigo,
            });
        });

        if(clientSearchController === controller){
            clientList.value = Array.from(uniqueClients.values());
        }
    }
    catch(err){
        if(err instanceof DOMException && err.name === "AbortError") return;
        console.error(`An error has just occurred: ${err}`);
    }
    finally{
        if(clientSearchController === controller){
            loadingClient.value = false;
        }
    }
}

async function GetRetailEmployees(){
    retailEmployeeList.value.length = 0;

    const params = new URLSearchParams();
    params.append("type", "quotation");

    await fetch(`${API_URL}/api/empleados?${params}`, {
        method:"GET",
        credentials: "include",
        headers: {"Content-Type": 'application/x-www-form-urlencoded'},
    }).then(async res =>{
        if(res.ok) return res.json();
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(response =>{
        const sellerList = response.data as Array<{codigo: string, nombre: string}>;
        sellerList.forEach(el => {
            let value: SelectField = {title: el.nombre, value: el.codigo};
            retailEmployeeList.value.push(value);
        });
    }).then(async () => {
        await fetch(`${API_URL}/api/empleados/retail/default`, {
            method:"GET",
            credentials: "include",
            headers: {"Content-Type": 'application/x-www-form-urlencoded'},
        }).then(async res =>{
            if(res.ok) return res.json();
            else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
        }).then(response2 =>{
            retailEmployeeVal.value = response2.data === "" ? retailEmployeeVal.value = "-1" : response2.data;
        });
    }).catch(err =>{
        console.error(`An error has just occurred: ${err}`);
    });
    
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

async function EditRequest(){
    loadModal.value = true;

    if(docDateVal.value == "" || docDueDateVal.value == "" || taxDateVal.value == "" || prcntPayAdvance.value.trim() == "" || prcntProjectStarted.value.trim() == "" ||(projectType.value == null || projectType.value == "") || project.value.trim() == "" || (quotationType.value == null || quotationType.value == "") || (clientVal.value == null || clientVal.value == "") || (retailEmployeeVal.value == null || retailEmployeeVal.value == "")){
        loadModal.value = false;
        
        toast.warning("Se deben llenar todos los campos obligatorios (*)", {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    }
    else if(comments.value.length > 254){
        loadModal.value = false;
        
        toast.warning("El valor colocado en el campo de comentarios es mayor al límite establecido (254 caracteres)", {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    }
    else if(reference.value.length > 200){
        loadModal.value = false;
        
        toast.warning("El valor colocado en el campo de referencia es mayor al límite establecido (200 caracteres)", {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    }
    else if(
        !Number.isFinite(Number(prcntPayAdvance.value)) ||
        !Number.isFinite(Number(prcntProjectStarted.value)) ||
        Number(prcntPayAdvance.value) < 0 ||
        Number(prcntProjectStarted.value) < 0 ||
        Number(prcntPayAdvance.value) > 100 ||
        Number(prcntProjectStarted.value) > 100 ||
        Math.abs((Number(prcntPayAdvance.value) + Number(prcntProjectStarted.value)) - 100) > 0.001
    ){
        loadModal.value = false;
        
        toast.warning("La suma de los porcentajes de pago anticipo y de proyecto arranque deben ser iguales al 100%", {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    }
    else if(articles.Length() == 0){
        loadModal.value = false;
        toast.warning("Se debe tener al menos un artículo o servicio agregado para crear la solicitud de compra", {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    }
    else{
        let foundError = false;
        const rows = articles.GetRows();
        for(let row = 0; row < articles.Length(); row++){
            if(rows[row].unitPrice.value == "") rows[row].unitPrice.value = 0;

            if(rows[row].article.value == null || rows[row].amount.value == ""){
                loadModal.value = false;
                foundError = true;
                toast.warning("Se deben llenar todos los campos obligatorios (*)", {
                    position: POSITION.BOTTOM_CENTER,
                    timeout: 2500,
                    pauseOnFocusLoss: false,
                    pauseOnHover: false,
                    hideProgressBar: true,
                    closeButton: false,
                    icon: false
                });
                break;
            }
            
        }

        if(foundError) return;
        let docLines: ERPSalesQuotationArticle[] = [];
        
        articles.GetRows().forEach(row => {
            const docLine: ERPSalesQuotationArticle = {
                article: row.article.value!,
                description: row.articleSearchElements.value.find(x => x.value == row.article.value!)?.title as string,
                quantity: row.amount.value.toString(),
                unitPrice: row.unitPrice.value.toString(),
                prcntDiscount: row.prcntDiscount.value.toString(),
                taxCode: row.impuesto.value,
                total: row.lineTotal.value.toString(),
                dim1: row.dim1.value,
                dim2: row.dim2.value,
                dim3: row.dim3.value,
                dim4: row.dim4.value,
                dim5: row.dim5.value
            }
            docLines.push(docLine);
        });

        body = {
            date1: docDateVal.value,
            date2: docDueDateVal.value,
            date3: taxDateVal.value,
            client: clientVal.value!,
            retailEmployee: retailEmployeeVal.value!,
            ref: reference.value.trim(),
            comm: comments.value.trim(),
            project: project.value.trim(),
            projectType: projectType.value,
            quotationType: quotationType.value,
            prcntPaymentAdvance: prcntPayAdvance.value,
            prcntPaymentStarted: prcntProjectStarted.value,
            documentLines: docLines
        }

        await fetch(`${API_URL}/api/cotizaciones/${docNum}`, {
            method: "PUT",
            credentials: "include",
            headers: {"Content-Type": 'application/json'},
            body: JSON.stringify(body)
        }).then(async res => {
            if(res.ok) return res.json();
            else if(res.status == 500){
                const serverErrorMsg = await res.text();
                const error = new Error(serverErrorMsg);
                error.name = "ServerError";
                throw error;
            }
            else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
        }).then(response => {
            if(response.data.name !== ""){
                const byteCharactersPDF = atob(response.data.document as string);
                const byteArrayPDF = new Uint8Array(byteCharactersPDF.length);

                for (let i = 0; i < byteCharactersPDF.length; i++) {
                    byteArrayPDF[i] = byteCharactersPDF.charCodeAt(i);
                }

                const blobPDF = new Blob([byteArrayPDF], { type: "application/pdf" });

                downloadBlob(blobPDF, response.data.name as string);
            }
            
            docDateVal.value = "";
            docDueDateVal.value = "";
            taxDateVal.value = "";
            clientVal.value = null;
            retailEmployeeVal.value = null;
            project.value = "";
            projectType.value = null;
            quotationType.value = null;
            prcntPayAdvance.value = "";
            prcntProjectStarted.value = "";
            reference.value = "";
            comments.value = "";

            articles.ClearTable();
            tableRef.value?.$forceUpdate();

            toast.success("Se ha editado la solicitud de forma exitosa", {
                position: POSITION.BOTTOM_CENTER,
                timeout: 2000,
                pauseOnFocusLoss: false,
                pauseOnHover: false,
                hideProgressBar: true,
                closeButton: false,
                icon: false
            });
            setTimeout(()=>{
                router.go(0);
            }, 2000);
        }).catch((err: Error) =>{
            let msg = "";
            if(err.name === "ServerError"){
                msg = err.message;
                console.error(err);
            }
            else{
                msg = `Ha ocurrido un error durante la edición del pedido. ${err}`;
                console.error(`An error has just occurred: ${err}`);
            }
            toast.error(msg, {
                position: POSITION.BOTTOM_CENTER,
                timeout: 3000,
                pauseOnFocusLoss: false,
                pauseOnHover: false,
                hideProgressBar: true,
                closeButton: false,
                icon: false
            });
        }).finally(() =>{loadModal.value = false;});
    }
}

function ConfirmEdit(isActive: Ref<boolean>){
    isActive.value = false;
    //The submit method needs to be called in this way, since the dialog is created outside the dom, which makes it not accesible directly to the submit method that could be inserted in the button of the dialog.
    form.value!.dispatchEvent(new SubmitEvent("submit", { cancelable: true, bubbles: true })); 
};

function UpdateTotal(element?: any){
    let component = element[0].$el as HTMLElement;
    const rowIndex: number = parseInt(component.parentNode!.parentNode!.children[0].textContent) - 1;
    const row = articles.GetRow(rowIndex);
    
    const basePrice: number = (Number(row.amount.value) * Number(row.unitPrice.value));
    const discountPercentage: number =  isNaN(Number(row.prcntDiscount.value)) ? 0.00 : Number(row.prcntDiscount.value);
    const discount: number = (100 - discountPercentage) / 100;
    
    row.lineTotal.value = basePrice * discount; 
    tableTotal.value = articles.CalculateTotal();
    tableRef.value?.$forceUpdate();
}

async function AddRow(){
    articles.AddRow(
        {
            article: ref(null),
            articleSearchElements: ref([]),
            articleSearchVal: ref(""),
            loadingSearchArtField: ref(false),
            description: ref(""),
            unitPrice: ref(0.00),
            amount: ref(1),
            lineTotal: ref(0.00),
            prcntDiscount: ref(""),
            impuesto: ref(""),
            dim1: ref(""),
            dim2: ref(""),
            dim3: ref(""),
            dim4: ref(""),
            dim5: ref("")
        }
    );
    articles.GetRow(articles.Length() - 1).impuesto.value = DEFAULT_SALESQUOT_TAX_CODE;
    articles.GetRow(articles.Length() - 1).prcntDiscount.value = "0.00";
    tableTotal.value = articles.CalculateTotal();

    tableRef.value?.$forceUpdate();
}

function DeleteRow(event: Event){
    const button = event.currentTarget as HTMLElement;
    const rowIndex: number = parseInt(button.parentNode!.parentNode!.parentNode!.children[0].textContent) - 1;
    articles.RemoveRow(rowIndex);

    tableTotal.value = articles.CalculateTotal();
    tableRef.value?.$forceUpdate();
}

const initializeColumnWidths = () => {
    headersArticle.forEach(header => {
        columnWidths[header.key] = header.width || 100;
    })
}

function startResize(event: MouseEvent, columnKey: string){
    event.preventDefault();
    event.stopPropagation();

    isResizing.value = true;
    resizingColumn.value = columnKey;
    startX.value = event.clientX;
    startWidth.value = columnWidths[columnKey];
}

function handleMouseMove(event: MouseEvent){
    if (!isResizing.value || !resizingColumn.value) return;

    const diff = event.clientX - startX.value;
    const newWidth = Math.max(40, startWidth.value + diff); 

    columnWidths[resizingColumn.value] = newWidth;
}

function handleMouseUp(){
    isResizing.value = false;
    resizingColumn.value = null;
    document.body.style.cursor = 'default';
}

async function getQuotationData(){
    const params = new URLSearchParams();
    params.append("id", docNum as string);
    params.append("type", "edit");

    await fetch(`${API_URL}/api/cotizaciones/detail?${params}`, {
        method:"GET",
        credentials: "include",
        headers: {"Content-Type": 'application/x-www-form-urlencoded'},
    }).then(res => {
        if(res.ok) return res.json();
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(response => {
        const order = response.data;
        
        docDateVal.value = order.docDate;
        docDueDateVal.value = order.docDueDate;
        taxDateVal.value = order.taxDate;
        clientList.value.push({value: order.clientId, title: order.clientName})
        clientVal.value = order.clientId;
        project.value = order.proyecto
        prcntProjectStarted.value = order.proyectoArrancado;
        prcntPayAdvance.value = order.anticipo;
        reference.value = order.reference;
        comments.value = order.comments;
        quotationType.value = order.cotizacion;
        projectType.value = order.tipoCotizador;
        
        (order.documentLines as {article: string, description: string, quantity: string, unitPrice: string, prcntDiscount: string, taxCode: string, total: string, dim1: string, dim2: string, dim3: string, dim4: string, dim5: string}[]).forEach(line => {
            articles.AddRow(
                {
                    article: ref(line.article),
                    articleSearchElements: ref([{value: line.article, title: line.description}]),
                    articleSearchVal: ref(""),
                    loadingSearchArtField: ref(false),
                    description: ref(`${line.article} - ${line.description}`),
                    unitPrice: ref(Number(line.unitPrice)),
                    amount: ref(Number(line.quantity)),
                    lineTotal: ref(0.00),
                    prcntDiscount: ref(line.prcntDiscount),
                    impuesto: ref(line.taxCode),
                    dim1: ref(line.dim1),
                    dim2: ref(line.dim2),
                    dim3: ref(line.dim3),
                    dim4: ref(line.dim4),
                    dim5: ref(line.dim5)
                }
            );

            const basePrice: number = (Number(line.quantity) * Number(line.unitPrice));
            const discountPercentage: number =  isNaN(Number(line.prcntDiscount)) ? 0.00 : Number(line.prcntDiscount);
            const discount: number = (100 - discountPercentage) / 100;
            
            articles.GetRow(articles.Length() - 1).lineTotal.value = basePrice * discount;
            tableTotal.value = articles.CalculateTotal();
            tableRef.value?.$forceUpdate();
        })
    });
}

function handleKeyDown(ev: KeyboardEvent){
    if(ev.shiftKey && ev.code == "Enter") {
        ev.preventDefault();
        AddRow();
    }
    else if(ev.shiftKey && ev.code === "Backspace" || ev.shiftKey && ev.code === "Delete"){
        ev.preventDefault();
        articles.RemoveRow(articles.Length() - 1);

        tableTotal.value = articles.CalculateTotal();
        tableRef.value?.$forceUpdate();
    }
}

onBeforeMount(async () => {
    loadModal.value = true;

    route.fullPath.split("/").slice(1).forEach((path) => {
        if(path === "cotizaciones") paths.SetItems({title: "Pedidos", disabled: true, href: ""});
        else if(path === "editar")paths.SetItems({title: "Editar", disabled: true, href: ""});
        else paths.SetItems({title: path.charAt(0).toUpperCase() + path.slice(1), disabled: false, href:path});
    })

    document.removeEventListener('mousemove', handleMouseMove)
    document.removeEventListener('mouseup', handleMouseUp)
    await GetRetailEmployees();

    await fetch(`${API_URL}/api/dimensiones`, {
        method:"GET",
        credentials: "include"
    }).then(res =>{
        if(res.ok) return res.json();
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(response =>{
        const dimensions = response.data as Array<{codigoDim: number, descDim: string, codigo: string, nombre: string}>;
        let actualDim = "";
        dimensions.forEach(val =>{
            let codigoDimension = val.codigoDim.toString();
            if(actualDim !== codigoDimension){
                actualDim = codigoDimension;
                listadoDimensiones.push(actualDim);
            }
            dimensionsElements.get(`dim${codigoDimension}`)!.values.value.push({title: val.codigo, subtitle: val.nombre});
        });
        
        for(let i = 0; i< headersArticle.length; i++){
            if(headersArticle[i].key.includes("dim")){
                const key: string = headersArticle[i].key.slice(-1);
                if(!listadoDimensiones.includes(key)){
                    headersArticle[i].enabled = false;
                    dimensionsElements.get(`dim${key}`)!.enabled.value = false;
                }
                else{
                    const index: number = dimensions.findIndex(dim => dim.codigoDim == parseInt(key));
                    headersArticle[i].title = dimensions[index].descDim;
                }
            }
        }
        tableRef.value?.$forceUpdate();
    }).catch(err =>{
        console.error(err);
    });

    const urlParams = new URLSearchParams();
    urlParams.append("category", "clients");

    await fetch(`${API_URL}/api/impuestos?${urlParams}`, {
        method: 'GET',
        credentials: 'include'
    }).then(res =>{
        if(res.ok) return res.json();
        else throw Error(`Ha ocurrido un error al buscar la lista de impuestos. Código de Estado: ${res.status}`);
    }).then(response =>{
        const impuestos = response.data as Array<{codigo: string, nombre: string}>
            
        impuestos.forEach(imp =>{
            taxList.push({title: imp.codigo, subtitle: imp.nombre});
        });
    }).catch(err =>{
        console.error(err);
    })
    await getQuotationData();

    loadModal.value = false;
})

onMounted(async ()=>{
    initializeColumnWidths();
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener("keydown", handleKeyDown);
});

onUnmounted(() => {
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
    document.removeEventListener("keydown", handleKeyDown);
});

defineExpose({
    resetColumnWidths: initializeColumnWidths,
    getColumnWidths: () => ({ ...columnWidths })
});
</script>
<style scoped src="@/scss/input.scss"></style>
<style scoped src="@/scss/pages/table.scss"></style>
<style scoped>
.article-description-cell{
    overflow: hidden;
}

.article-description-text{
    display: block;
    width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

@media(width >= 620px){
    .btn-group{
        display: grid;
        grid-template-columns: repeat(12, 1fr);
        grid-template-rows: repeat(1, 1fr);
        gap: 10px;
    }

    .table-setup{
        display: grid;
        grid-template-columns: repeat(12, 1fr);
        grid-template-rows: repeat(1, 1fr);
        gap: 0px;
    }
}
@media(width < 620px){
    .btn-group{
        display: grid;
        grid-template-columns: repeat(12, 1fr);
        grid-template-rows: repeat(2, 1fr);
        gap: 10px;
    }
    .opt2 {
        grid-row-start: 2;
    }

    .table-setup{
        display: grid;
        grid-template-columns: repeat(12, 1fr);
        grid-template-rows: repeat(2, 1fr);
        gap: 10px;
    }
}
</style>

