<template>
    <section>
        <v-breadcrumbs :items="paths.GetItems()" class="ml-3 text-body-small pb-0 pt-2">
            <template v-slot:prepend>
                <v-icon icon="mdi-home" size="small"></v-icon>
            </template>
        </v-breadcrumbs>
        <p class="text-headline-small font-weight-medium ml-6 my-1">Pedidos Pendientes</p>
    </section>
    <section>
        <v-form @submit.prevent="SearchData">
            <v-container class="ma-0 px-6 pb-0" fluid>
                <v-row density="comfortable">
                    <v-col xs="12" md="4" cols="12">
                        <DatePicker field-label="Fecha Inicial" name="start_date" v-model="initialDate"/>
                    </v-col>
                    <v-col xs="12" md="4" cols="12">
                        <DatePicker field-label="Fecha Final" name="end_date" v-model="endDate"/>
                    </v-col>
                    <v-col xs="12" md="4" cols="12">
                        <v-btn prepend-icon="mdi-magnify" color="#0AB39C" class="text-none" size="small" type="submit"><small>Buscar</small></v-btn>
                    </v-col>
                </v-row>
                <v-divider opacity="0.7" class="my-2"></v-divider>
                <v-row density="comfortable">
                    <v-col xs="12" md="3" cols="12">
                        <v-text-field label="Filtrar por Proyecto" type="text" variant="outlined" density="compact" hide-details="auto" class="input" name="project" v-model="cotSearchName" maxlength="30"></v-text-field>
                    </v-col>
                </v-row>
            </v-container>
        </v-form>
    </section>
    <v-divider class="border-opacity-100 mx-2 mb-2 mt-2"></v-divider>
    <section>
        <v-card class="mx-6 pa-2 mt-2">
            <v-data-table :headers="activeHeaders" striped="odd" :items="tableData" :search="cotSearchName" :filter-keys="['project_name']" height="25rem" density="compact" items-per-page-text="Elementos por página"  no-data-text="No se encontraron pedidos" hover>
                <template v-slot:item.check_detail="{ item }">
                    <v-btn prepend-icon="mdi-arrow-right" color="#0AB39C" size="small" class="text-none" variant="text" :to="`/cotizaciones/${item.docNum}`"><small>Ver Detalle</small></v-btn>
                </template>

                <template v-slot:item.actions="{ item }">
                    <div class="action-buttons">
                        <div class="action-1">
                            <v-btn prepend-icon="mdi-pencil-outline" color="#F0AD4E" size="small" class="text-none" :to="`/cotizaciones/editar/${item.docNum}`"><small>Editar</small></v-btn>
                        </div>
                        <div class="action-2">
                            <v-dialog min-width="300" max-width="400">
                                <template v-slot:activator="{ props: activatorProps }">
                                    <v-btn prepend-icon="mdi-check" color="#0AB39C" size="small" class="text-none" v-bind="activatorProps"><small>Subir a SAP</small></v-btn>
                                </template>
                                <template v-slot:default="{ isActive }">
                                    <v-card>
                                        <v-card-title class="font-weight-bold">Subir Pedido</v-card-title>
                                        <v-card-text class="text-center">
                                            ¿Está seguro que desea subir a SAP el pedido? No se podrá revertir la acción.
                                        </v-card-text>
                                        <v-card-actions>
                                            <v-btn color="#0AB39C" class="text-none" @click="UploadQuotation(isActive, item.docNum)">Confirmar</v-btn>
                                            <v-btn color="#D9534F" @click="isActive.value = false" class="text-none">Regresar</v-btn>
                                        </v-card-actions>
                                    </v-card>
                                </template>
                            </v-dialog>
                        </div>
                    </div>
                </template>
            </v-data-table>
        </v-card>
    </section>
    <v-dialog v-model="loadModal" persistent no-click-animation>
        <div class="text-center">
        <v-progress-circular color="primary" :size="72" :width="7" indeterminate></v-progress-circular>
        </div>
    </v-dialog>
</template>
<script setup lang="ts">
import { useHead } from '@unhead/vue';
import { useRoute, useRouter, type RouteLocationNormalizedLoadedGeneric, type Router } from 'vue-router';
import { computed, onBeforeMount, ref, type ComputedRef, type Ref } from 'vue';
import BreadCrumb from '@/assets/ts/classes/pages/Breadcrumb';
import DatePicker from '@/components/custom/fields/DatePicker.vue';
import { POSITION, useToast } from "vue-toastification";
import { API_URL } from '@/config/env.config';

useHead({
    title: "Estatus de Solicitudes"
})

//Route and router variables for going to other pages of the website or seing the actual path
const route: RouteLocationNormalizedLoadedGeneric = useRoute();
const router: Router = useRouter();
const role: Ref<string> = ref("");
const toast = useToast(); //toast variable for creating toast notifications

const paths: BreadCrumb = new BreadCrumb();

//Section with the constants that will store the reactive values of the fields in the header.
const initialDate: Ref<string> = ref("");
const endDate: Ref<string> = ref("");
const cotSearchName: Ref<string> = ref("");

const tableHeaders: Array<any> = [
    { width: 100, title: '#', key: 'table_id', align: 'start', sortable: true, condition: () => true },
    { width: 200, title: 'ID Doc', key: 'docNum', align: 'start', sortable: true, condition: () => false },
    { width: 500, title: 'Proyecto', key: 'project_name', align: 'start', sortable: true, condition: () => true },
    { width: 100, title: 'Fecha de Contabilización', key: 'doc_date', align: 'start', sortable: true, condition: () => true },
    { width: 300, title: 'Usuario', key: 'user', align: 'start', sortable: true, condition: () => role.value === "2"},
    { width: 300, title: 'Total', key: 'total', align: 'start', sortable: true, condition: () => true },
    { width: 300, title: 'Detalle', key: 'check_detail', align: 'start', sortable: false, condition: () => true },
    { width: 300, title: 'Acciones', key: 'actions', align: 'start', sortable: false, condition: () => true }
];

const activeHeaders: ComputedRef<any[]> = computed(() => {
    return tableHeaders.filter(col => col.condition());
});

const loadModal: Ref<boolean> = ref(false);

const tableData: Ref<Array<{table_id: string, docNum: string, project_name: string, doc_date: string, user?: string, total: string}>> = ref([])
//#TODO añadir funcionalidad backend que recupere en los filtros el nombre del proyecto en Reportes y en Pendiente
async function SearchData(){
    if(initialDate.value == ""){
        toast.warning("Se debe tener una fecha inicial", {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    }
    else{
        loadModal.value = true;
        tableData.value.length = 0;

        let date1: string | null = null;
        let date2: string | null = null;

        const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
        const f = new Intl.DateTimeFormat("es-mx", options as any)

        if(initialDate.value != "") date1 = initialDate.value;
        else date1 = "";

        if(endDate.value == ""){
            let temp: string[] = f.format(Date.now()).split("/");
            date2 = `${temp[2]}/${temp[1]}/${temp[0]}`;
        }
        else date2 = endDate.value;

        const params = new URLSearchParams();
        params.append("initialDate", date1);
        params.append("endDate", date2);
       
        await fetch(`${API_URL}/api/cotizaciones/filter?${params}`, {
            method:"GET",
            credentials: "include",
            headers: {"Content-Type": 'application/x-www-form-urlencoded'}
        }).then(async res => {
            if(res.ok) return res.json();
            else if(res.status == 500){
                const errMsg = await res.text();
                const error = new Error(errMsg);
                error.name = "ServerError";

                throw error;
            }
            else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
        }).then(response => {
            let purchaseOrders = response.data as Array<{docNum: string, docDate: string, project: string, user?: string, total: string}>
            
                purchaseOrders.forEach((order, index) =>{
                    if(role.value === "2"){
                        tableData.value.push({
                            table_id: (index + 1).toString(),
                            docNum: order.docNum,
                            project_name: order.project,
                            doc_date: order.docDate,
                            user: order.user,
                            total: `$${order.total}`
                        });
                    }
                    else{
                        tableData.value.push({
                            table_id: (index + 1).toString(),
                            docNum: order.docNum,
                            project_name: order.project,
                            doc_date: order.docDate,
                            total: `$${order.total}`
                        });
                    }
                });
        }).catch(err => {
            let msg = "";
            if(err.name === "ServerError"){
                msg = err.message;
                console.error(msg);
            }
            else{
                msg = `Ha ocurrido un error al filtrar la búsqueda de pedidos. ${err}`;
                console.error(msg);
            }
            
            toast.error(msg, {
                position: POSITION.BOTTOM_CENTER,
                timeout: 2500,
                pauseOnFocusLoss: false,
                pauseOnHover: false,
                hideProgressBar: true,
                closeButton: false,
                icon: false
            });
        }).finally(() => {loadModal.value = false;});
    }
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

async function UploadQuotation(isActive: Ref<boolean>, docNum: string){
    isActive.value = false;
    loadModal.value = true;

    const body = {
        id: docNum
    }

    await fetch(`${API_URL}/api/cotizaciones/upload`, {
        method:"POST",
        credentials: "include",
        headers: {"Content-Type": 'application/json'},
        body: JSON.stringify(body)
    }).then(async res =>{
        if(res.status === 201 || res.status === 202){
            let responseBody = await res.json();
            responseBody["status"] = res.status;
            return responseBody;
        }
        else if(res.status == 500){
            const errMsg = await res.text();
            const error = new Error(errMsg);
            error.name = "ServerError";

            throw error;
        }
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(response =>{
        const rowIndex: number = tableData.value.findIndex(row => row.docNum === docNum)
        tableData.value.splice(rowIndex, 1);

        if(response.status == 201){
            const byteCharactersPDF = atob(response.data.document as string);
            const byteArrayPDF = new Uint8Array(byteCharactersPDF.length);

            for (let i = 0; i < byteCharactersPDF.length; i++) {
                byteArrayPDF[i] = byteCharactersPDF.charCodeAt(i);
            }

            const blobPDF = new Blob([byteArrayPDF], { type: "application/pdf" });

            downloadBlob(blobPDF, response.data.name as string);
            
            toast.success("Se ha subido con éxito el pedido a SAP", {
                position: POSITION.BOTTOM_CENTER,
                timeout: 2500,
                pauseOnFocusLoss: false,
                pauseOnHover: false,
                hideProgressBar: true,
                closeButton: false,
                icon: false
            });
        }
        else{
            console.warn(`Se ha subido con éxito el pedido a SAP, pero ha ocurrido un problema durante la generación del PDF. Motivo: ${response.data}`);
            toast.success(`Se ha subido con éxito el pedido a SAP, pero ha ocurrido un problema durante la generación del PDF. ${response.data}`, {
                position: POSITION.BOTTOM_CENTER,
                timeout: 2500,
                pauseOnFocusLoss: false,
                pauseOnHover: false,
                hideProgressBar: true,
                closeButton: false,
                icon: false
            });
        }
    }).catch((err: Error) =>{
        let msg = "";
        if(err.name === "ServerError"){
            msg = err.message;
            console.error(msg);
        }
        else{
            msg = `Ha ocurrido un error al intentar subir a SAP el pedido. ${err}`;
            console.error(msg);
        }
        
        toast.error(msg, {
            position: POSITION.BOTTOM_CENTER,
            timeout: 2500,
            pauseOnFocusLoss: false,
            pauseOnHover: false,
            hideProgressBar: true,
            closeButton: false,
            icon: false
        });
    }).finally(()=>{loadModal.value = false;})
}

onBeforeMount(async () => {
    route.fullPath.split("/").slice(1).forEach((path) => {
        if(path === "cotizaciones") paths.SetItems({title: "Pedidos", disabled: true, href: ""});
        else paths.SetItems({title: path.charAt(0).toUpperCase() + path.slice(1), disabled: false, href:path});
    })
    
    const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
    const f = new Intl.DateTimeFormat("es-mx", options as any)

    let tempDateFormat: string[] = f.format(Date.now()).split("/");
    let date = `${tempDateFormat[2]}/${tempDateFormat[1]}/${tempDateFormat[0]}`;
    
    const params = new URLSearchParams();
    params.append("date", date);

    await fetch(`${API_URL}/api/auth/user-info`, {
        method:"GET",
        credentials: "include",
    }).then(res => {
        if (res.ok) return res.json();
        else if(res.status === 401 || res.status === 404) throw Error("No se encontró una sesión activa")
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(async response => {
        role.value = response.rol;
    }).catch(err =>{
        console.error(err);
    });

    await fetch(`${API_URL}/api/cotizaciones?${params}`, {
        method:"GET",
        credentials: "include",
        headers: {"Content-Type": 'application/x-www-form-urlencoded'}
    }).then(res =>{
        if(res.ok) return res.json();
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(response =>{
        let purchaseOrders = response.data as Array<{docNum: string, docDate: string, project: string, user?: string, total: string}>
        purchaseOrders.forEach((order, index) =>{
            if(role.value === "2"){
                tableData.value.push({
                    table_id: (index + 1).toString(),
                    docNum: order.docNum,
                    project_name: order.project,
                    doc_date: order.docDate,
                    user: order.user,
                    total: `$${order.total}`
                });
            }
            else{
                tableData.value.push({
                    table_id: (index + 1).toString(),
                    docNum: order.docNum,
                    project_name: order.project,
                    doc_date: order.docDate,
                    total: `$${order.total}`
                });
            }
            
        });
    }).catch(err =>{
        console.error(err);
    });
})
</script>
<style scoped src="@/scss/input.scss"></style>
<style scoped src="@/scss/pages/table.scss"></style>
<style scoped>
.action-buttons{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: repeat(1, 1fr);
    gap: 5px;
}
</style>