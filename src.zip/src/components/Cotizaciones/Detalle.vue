<template>
    <section>
        <v-breadcrumbs :items="paths.GetItems()" class="ml-3 text-body-small pb-0 pt-2">
            <template v-slot:prepend>
                <v-icon icon="mdi-home" size="small"></v-icon>
            </template>
        </v-breadcrumbs>
        <p class="text-headline-small font-weight-medium ml-6">Detalle de Pedido</p>
    </section>
    <section>
      <div>
        <p class="text-headline-small font-weight-medium ml-6 mt-2 mb-0">Pedido: <small>{{ quotation.docId.value }}</small></p>
        <v-chip v-if="quotation.sapUploaded.value" class="ml-6" prepend-icon="mdi-check-circle-outline" density="compact" size="small" label color="#0AB39C">Subido a SAP</v-chip>
        <v-chip v-else-if="quotation.sapUploaded.value == false && quotation.failed.value == false" class="ml-6" prepend-icon="mdi-clock-outline" density="compact" size="small" color="#2B4FC4" label>En espera para subirse a SAP</v-chip>
        <v-chip v-else class="ml-6" prepend-icon="mdi-cancel" density="compact" size="small" color="#D9534F" label>Subida a SAP fallida. Require reenvío</v-chip>
      </div>
      <div class="header-elements mx-6 mt-2">
        <div class="el-1">
          <p class="text-body-medium"><span class="font-weight-medium">Fecha Contabilización:</span> {{ quotation.docDate.value }}</p>
          <p class="text-body-medium"><span class="font-weight-medium">Válido Hasta:</span> {{ quotation.docDueDate.value }}</p>
        </div>
        <div class="el-2">
          <p class="text-body-medium"><span class="font-weight-medium">Fecha de Documento:</span> {{ quotation.taxDate.value }}</p>
          <p class="text-body-medium"><span class="font-weight-medium">Referencia:</span> {{ quotation.ref.value }}</p>

        </div>
        <div class="el-3">
          <p class="text-body-medium"><span class="font-weight-medium">Cliente:</span> {{ quotation.clientId.value }} - {{ quotation.clientName.value }}</p>
          <p class="text-body-medium"><span class="font-weight-medium">Empleado de depto. ventas:</span> {{ quotation.retailSeller.value }}</p>
        </div>
        <div class="el-4">
          <p class="text-body-medium"><span class="font-weight-medium">Solicitante:</span> {{ quotation.employeeID.value }} - {{ quotation.employeeName.value }}</p>
          <p class="text-body-medium"><span class="font-weight-medium">Proyecto:</span> {{ quotation.proyecto.value }}</p>
        </div>
        <div class="el-5">
          <p class="text-body-medium"><span class="font-weight-medium">Anticipo:</span> {{ quotation.anticipo.value }}%</p>
          <p class="text-body-medium"><span class="font-weight-medium">Proyecto Arrancado</span> {{ quotation.proyectoArrancado.value }}%</p>
        </div>
        <div class="el-6">
          <p class="text-body-medium"><span class="font-weight-medium">Tipo Cotizador:</span> {{ quotation.tipoCotizador.value }}</p>
          <p class="text-body-medium"><span class="font-weight-medium">Pedido:</span> {{ quotation.cotizacion.value }}</p>
        </div>
        <div class="el-7">
          <p class="text-body-medium"><span class="font-weight-medium">Comentarios:</span> {{ quotation.comments.value }}</p>
          <p v-if="quotation.sapUploaded.value" class="text-body-medium"><span class="font-weight-medium">Archivo:</span> <span style="text-decoration: underline; color: blue; cursor: pointer;" @click="downloadPdf">{{ fileName }}</span></p>
        </div>
        <div class="el-8">
          <p class="text-body-medium"><span class="font-weight-medium">ID SAP:</span> {{ quotation.docEntrySAP.value }}</p>
          <p class="text-body-medium"><span class="font-weight-medium">Estatus en SAP:</span> {{ quotation.docStatus.value }}</p>
        </div>
      </div>
    </section>
    <v-divider class="border-opacity-100 mx-2 mb-2 mt-2"></v-divider>
    <section>
      <p class="text-h6 font-weight-medium ml-6 mt-2">Contenido</p>
    
      <v-card class="mx-6 pa-2 mt-2" color="#D9D9D9">
        <v-table striped="odd" height="21rem" fixed-header hide-default-footer hover density="compact">
          <thead>
            <tr>
              <template v-for="header in headersArticle">
                <th v-if="header.enabled" :class="`text-${header.align} header-content`" :key="header.key" :style="{width: columnWidths[header.key] + 'px', minWidth: columnWidths[header.key] + 'px', maxWidth: columnWidths[header.key] + 'px'}">
                  <div class="header-inner">
                    <div class="header-text" :title="header.title">
                      <v-tooltip :text="`${header.title}`" location="top" :open-on-hover="false" open-on-click>
                        <template v-slot:activator="{ props }">
                          <p v-bind="props">{{ header.title }}</p>
                        </template>
                      </v-tooltip>
                    </div>
                    <div class="resize-handle" @mousedown="startResize($event,header.key)"></div>
                  </div>
                </th>
              </template>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(article, index) in (quotation.documentLines.value as ERPSalesQuotationArticle[])" :key="`article-${index}`">
                <td >{{ index + 1 }}</td>
                <td>{{ article.article }}</td>
                <td>{{ article.description }}</td>
                <td>{{ article.quantity }}</td>
                <td>{{ article.unitPrice }}</td>
                <td>{{ article.prcntDiscount }}</td>
                <td>{{ article.taxCode }}</td>
                <td>${{ article.total}}</td>
                <td v-if="dimensionsElements.get('dim1')!.enabled.value">{{ article.dim1 }}</td>
                <td v-if="dimensionsElements.get('dim2')!.enabled.value">{{ article.dim2 }}</td>
                <td v-if="dimensionsElements.get('dim3')!.enabled.value">{{ article.dim3 }}</td>
                <td v-if="dimensionsElements.get('dim4')!.enabled.value">{{ article.dim4 }}</td>
                <td v-if="dimensionsElements.get('dim5')!.enabled.value">{{ article.dim5 }}</td>
            </tr>
          </tbody>
        </v-table>
      </v-card>
    </section>
    <v-dialog v-model="loadModal" persistent no-click-animation>
        <div class="text-center">
        <v-progress-circular color="primary" :size="72" :width="7" indeterminate></v-progress-circular>
        </div>
    </v-dialog>
</template>
<script setup lang="ts">
import BreadCrumb from '@/assets/ts/classes/pages/Breadcrumb';
import type { DocTypeHeaders } from '@/assets/ts/interfaces/documentType/interfaces';
import type { DimensionDescription, ERPSalesQuotationArticle, SalesQuotationInfo } from '@/assets/ts/interfaces/pages/interfaces';
import { API_URL } from '@/config/env.config';
import { useHead } from '@unhead/vue';
import { onBeforeMount, onMounted, reactive, ref, watch, type Ref } from 'vue'
import { useRoute, type RouteLocationNormalizedLoadedGeneric } from 'vue-router'
import { POSITION, useToast } from 'vue-toastification';

useHead({
    title: "Detalle de Solicitud"
})

const route: RouteLocationNormalizedLoadedGeneric = useRoute()
const loadModal: Ref<boolean> = ref(false);
const fileName: Ref<string> = ref("");
const paths: BreadCrumb = new BreadCrumb();
const docNum = route.params.id;
const toast = useToast();
const quotation: SalesQuotationInfo = {
  failed: ref(false),
  sapUploaded: ref(false),
  docId: ref(""),
  docDate: ref(""),
  docDueDate: ref(""),
  taxDate: ref(""),
  clientId: ref(""),
  clientName: ref(""),
  retailSeller: ref(""),
  employeeID: ref(""),
  employeeName: ref(""),
  comments: ref(""),
  ref: ref(""),
  docStatus: ref(""),
  docEntrySAP: ref(""),
  proyecto: ref(""),
  anticipo: ref(""),
  proyectoArrancado: ref(""),
  tipoCotizador: ref(""),
  cotizacion: ref(""),
  documentLines: ref([])
};

let columnWidths: {[key: string]: number} = reactive({});
const isResizing: Ref<boolean> = ref(false);
const resizingColumn: Ref<string | null> = ref(null);
const startX = ref(0);
const startWidth = ref(0);

const headersArticle: DocTypeHeaders[] = [
  {title: "#", key: "art-tableID", align: "center", width: 30, enabled: true},
  {title: "Articulo", key: "art-article", align: "center", width: 170, enabled: true},
  {title: "Nombre Cotizador", key: "art-desc", align: "center", width: 200, enabled: true},
  {title: "Cantidad", key: "art-amount", align: "center", width: 110, enabled: true},
  {title: "Precio Unitario", key: "art-unitPrice", align: "center", width: 140, enabled: true},
  {title: "% de descuento", key: "art-prcntDiscount", align: "center", width: 140, enabled: true},
  {title: "Indicador de impuestos", key: "art-taxCode", align: "center", width: 140, enabled: true},
  {title: "Total", key: "line-total", align: "center", width: 110, enabled: true},
  {title: "Centro de Costos 1", key: "art-dim1", align: "center", width: 100, enabled: true},
  {title: "Centro de Costos 2", key: "art-dim2", align: "center", width: 100, enabled: true},
  {title: "Centro de Costos 3", key: "art-dim3", align: "center", width: 100, enabled: true},
  {title: "Centro de Costos 4", key: "art-dim4", align: "center", width: 100, enabled: true},
  {title: "Centro de Costos 5", key: "art-dim5", align: "center", width: 100, enabled: true}
]

let listadoDimensiones: string[] = [];

let dimensionsElements: Map<string, DimensionDescription> = new Map<string, DimensionDescription>();

dimensionsElements.set("dim1", {enabled: ref(true), values: ref([])});
dimensionsElements.set("dim2", {enabled: ref(true), values: ref([])});
dimensionsElements.set("dim3", {enabled: ref(true), values: ref([])});
dimensionsElements.set("dim4", {enabled: ref(true), values: ref([])});
dimensionsElements.set("dim5", {enabled: ref(true), values: ref([])});

const initializeColumnWidths = () => {
    headersArticle.forEach(header => {
            columnWidths[header.key] = header.width || 100 
    })
}

function startResize(event: MouseEvent, columnKey: string){
    event.preventDefault();
    event.stopPropagation();

    isResizing.value = true;
    resizingColumn.value = columnKey;
    startX.value = event.clientX;
    startWidth.value = columnWidths[columnKey]
}

function handleMouseMove(event: MouseEvent){
    if (!isResizing.value || !resizingColumn.value) return

    const diff = event.clientX - startX.value
    const newWidth = Math.max(40, startWidth.value + diff) 

    columnWidths[resizingColumn.value] = newWidth
}

function handleMouseUp(){
    isResizing.value = false;
    resizingColumn.value = null;
    document.body.style.cursor = 'default';
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

async function downloadPdf(){
  loadModal.value = true;

  const params = new URLSearchParams();
  params.append("id", docNum as string);

  await fetch(`${API_URL}/api/cotizaciones/pdf?${params}`, {
    method: "GET",
    credentials: "include",
    headers: {"Content-Type": 'application/x-www-form-urlencoded'}
  }).then(async res => {
    if(res.ok) return res.json();
    else if(res.status == 500){
      const errMsg = await res.text();
      const error = new Error(errMsg);
      error.name = "ServerError";

      throw error;
    }
    else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
  }).then(response =>{
      const byteCharactersPDF = atob(response.data.document as string);
      const byteArrayPDF = new Uint8Array(byteCharactersPDF.length);

      for (let i = 0; i < byteCharactersPDF.length; i++) {
          byteArrayPDF[i] = byteCharactersPDF.charCodeAt(i);
      }

      const blobPDF = new Blob([byteArrayPDF], { type: "application/pdf" });

      downloadBlob(blobPDF, response.data.name as string);
      
      toast.success("Se ha descargado con éxito el pedido", {
          position: POSITION.BOTTOM_CENTER,
          timeout: 2500,
          pauseOnFocusLoss: false,
          pauseOnHover: false,
          hideProgressBar: true,
          closeButton: false,
          icon: false
      });
  }).catch((err: Error) => {
    let msg = "";
    if(err.name === "ServerError"){
        msg = err.message;
        console.error(msg);
    }
    else{
        msg = `Ha ocurrido un error al intentar obtener el documento del pedido. ${err}`;
        console.error(msg);
    }
    
    toast.error(msg, {
        position: POSITION.BOTTOM_CENTER,
        timeout: 2500,
        pauseOnFocusLoss: false,
        pauseOnHover: false,
        hideProgressBar: true,
        closeButton: false,
        icon: false
    });
  }).finally(() => {loadModal.value = false;});
}

onBeforeMount(async () => {
  loadModal.value = true;

  route.fullPath.split("/").slice(1).forEach((path) => {
    if(path === "cotizaciones") paths.SetItems({title: "Pedidos", disabled: true, href: ""});
    else paths.SetItems({title: path.charAt(0).toUpperCase() + path.slice(1), disabled: false, href:path});
  })

  document.removeEventListener('mousemove', handleMouseMove)
  document.removeEventListener('mouseup', handleMouseUp)

  await fetch(`${API_URL}/api/dimensiones`, {
        method:"GET",
        credentials: "include"
    }).then(res =>{
        if(res.ok) return res.json();
        else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
    }).then(response =>{
        const dimensions = response.data as Array<{codigoDim: number, descDim: string, codigo: string, nombre: string}>;
        let actualDim = "";
        dimensions.forEach(val =>{
            let codigoDimension = val.codigoDim.toString();
            if(actualDim !== codigoDimension){
                actualDim = codigoDimension;
                listadoDimensiones.push(actualDim);
            }
            dimensionsElements.get(`dim${codigoDimension}`)!.values.value.push({title: val.codigo, subtitle: val.nombre});
        });
        
        for(let i = 0; i< headersArticle.length; i++){
            if(headersArticle[i].key.includes("dim")){
                const key: string = headersArticle[i].key.slice(-1);
                if(!listadoDimensiones.includes(key)){
                    headersArticle[i].enabled = false;
                    dimensionsElements.get(`dim${key}`)!.enabled.value = false;
                }
                else{
                    const index: number = dimensions.findIndex(dim => dim.codigoDim == parseInt(key));
                    headersArticle[i].title = dimensions[index].descDim
                }
            }
        }
    }).catch(err =>{
        console.error(err)
    });

  const params = new URLSearchParams();
  params.append("id", docNum as string);
  params.append("type", "review");

  await fetch(`${API_URL}/api/cotizaciones/detail?${params}`, {
    method:"GET",
    credentials: "include",
    headers: {"Content-Type": 'application/x-www-form-urlencoded'},
  }).then(res => {
    if(res.ok) return res.json();
    else throw Error(`Error de comunicación con la API o de respuesta de la API. Código de Estado: ${res.status}`);
  }).then(response => {
    const order = response.data;
    
    quotation.failed.value = order.failed,
    quotation.sapUploaded.value = order.sapUploaded,
    quotation.docId.value = order.docId,
    quotation.docDate.value = order.docDate,
    quotation.docDueDate.value = order.docDueDate,
    quotation.taxDate.value = order.taxDate,
    quotation.clientId.value = order.clientId,
    quotation.clientName.value = order.clientName,
    quotation.retailSeller.value = order.retailSeller,
    quotation.employeeID.value = order.employeeID,
    quotation.employeeName.value = order.employeeName,
    quotation.taxDate.value = order.taxDate,
    quotation.comments.value = order.comments,
    quotation.ref.value = order.reference,
    quotation.docStatus.value = order.docStatus,
    quotation.docEntrySAP.value = order.docEntrySAP,
    quotation.proyecto.value = order.proyecto,
    quotation.anticipo.value = order.anticipo,
    quotation.proyectoArrancado.value = order.proyectoArrancado,
    quotation.tipoCotizador.value = order.tipoCotizador,
    quotation.cotizacion.value = order.cotizacion,
    quotation.documentLines.value = order.documentLines
    
    if(order.sapUploaded) fileName.value = `${(order.proyecto as string).replaceAll(/\s+/g, "_")}_${(order.docDate as string).replaceAll("/", "")}_${order.docEntrySAP}.pdf`
  }).catch(err =>{
    console.error(err);
  });

  loadModal.value = false;
});

onMounted(async ()=>{
    initializeColumnWidths();
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
})

defineExpose({
    resetColumnWidths: initializeColumnWidths,
    getColumnWidths: () => ({ ...columnWidths })
})
</script>
<style scoped src="@/scss/pages/table.scss"></style>
<style scoped>
@media(width >= 700px){
  .header-elements{
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    grid-template-rows: repeat(4, 1fr);
    row-gap: 5px;
    column-gap: 5px;
  }

  .el-1 {
    grid-column: span 6 / span 6;
  }

  .el-2 {
    grid-column: span 6 / span 6;
    grid-column-start: 7;
  }

  .el-3 {
    grid-column: span 6 / span 6;
    grid-row-start: 2;
  }

  .el-4 {
    grid-column: span 6 / span 6;
    grid-column-start: 7;
    grid-row-start: 2;
  }

  .el-5 {
    grid-column: span 6 / span 6;
    grid-row-start: 3;
  }
  .el-6 {
    grid-column: span 6 / span 6;
    grid-column-start: 7;
    grid-row-start: 3;
  }
  .el-7 {
    grid-column: span 6 / span 6;
    grid-row-start: 4;
  }
  .el-8 {
    grid-column: span 6 / span 6;
    grid-column-start: 7;
    grid-row-start: 4;
  }
}
@media(width < 700px){
  .parent {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    grid-template-rows: repeat(8, 1fr);
    gap: 8px;
  }

  .el-1 {
    grid-column: span 4 / span 4;
  }

  .el-2 {
    grid-column: span 4 / span 4;
    grid-row-start: 2;
  }

  .el-3 {
    grid-column: span 4 / span 4;
    grid-row-start: 3;
  }

  .el-4 {
    grid-column: span 4 / span 4;
    grid-row-start: 4;
  }

  .el-5 {
    grid-column: span 4 / span 4;
    grid-row-start: 5;
  }

  .el-6 {
    grid-column: span 4 / span 4;
    grid-row-start: 6;
  }
  .el-7 {
    grid-column: span 4 / span 4;
    grid-row-start: 7;
  }
  .el-8 {
    grid-column: span 4 / span 4;
    grid-row-start: 8;
  }

}
</style>