<template>
  <section id="login">
    <div class="login-brand" aria-label="SPM Innovación y Tecnología">
      <img
        src="/images/SPMsinfondo.png"
        alt="SPM Innovación y Tecnología"
        class="login-logo"
      />
    </div>

    <v-card
      height="310px"
      width="400px"
      color="rgba(255, 255, 255, 0.82)"
      class="login-card px-8 py-3 mx-5"
    >
      <p class="text-headline-large text-center mt-5 mb-5">Acceso</p>

      <v-form @submit.prevent="Login">
        <v-text-field
          label="Usuario"
          variant="solo"
          type="text"
          v-model="formData.user.value.value"
        />

        <v-text-field
          label="Contraseña"
          variant="solo"
          :append-inner-icon="viewPass ? 'mdi-eye-off-outline' : 'mdi-eye-outline'"
          @click:append-inner="viewPass = !viewPass"
          :type="viewPass ? 'text' : 'password'"
          v-model="formData.password.value.value"
        />

        <v-btn
          class="text-none font-weight-bold"
          block
          color="#F0AD4E"
          type="submit"
        >
          Iniciar Sesión
        </v-btn>
      </v-form>
    </v-card>
  </section>

  <v-dialog v-model="loadModal" persistent no-click-animation>
    <div class="text-center">
      <v-progress-circular
        color="primary"
        :size="72"
        :width="7"
        indeterminate
      />
    </div>
  </v-dialog>
</template>

<script setup lang="ts">
import { useField, useForm } from "vee-validate";
import { useHead } from "@unhead/vue";
import { ref } from "vue";
import { useRouter } from "vue-router";
import { POSITION, useToast } from "vue-toastification";
import { API_URL } from "@/config/env.config";

useHead({
  title: "Login - Portal Pedidos"
});

const viewPass = ref(false);
const loadModal = ref(false);
const toast = useToast();
const router = useRouter();

const { handleSubmit } = useForm({
  validationSchema: {}
});

const formData = {
  user: useField("user"),
  password: useField("password")
};

const Login = handleSubmit(async (values, { resetForm }) => {
  loadModal.value = true;

  const body = {
    user: values["user"],
    password: values["password"]
  };

  await fetch(`${API_URL}/api/auth/signin`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })
    .then(async (res) => {
      if (res.ok) {
        return res.text();
      }

      if (res.status === 401) {
        const errorMessage = await res.text();
        const error = new Error(errorMessage);
        error.name = "AuthError";
        throw error;
      }

      const errorMessage = await res.text();
      throw new Error(
        errorMessage ||
          `Error de comunicación con la API. Código de Estado: ${res.status}`
      );
    })
    .then(async () => {
      resetForm();
      loadModal.value = false;

      await router.push("/");
      router.go(0);
    })
    .catch((err: Error) => {
      loadModal.value = false;
      console.error(`${err}`);

      if (err.name === "AuthError") {
        toast.error(`No se ha podido iniciar sesión. ${err.message}`, {
          position: POSITION.BOTTOM_CENTER,
          timeout: 2500,
          pauseOnFocusLoss: false,
          pauseOnHover: false,
          hideProgressBar: true,
          closeButton: false,
          icon: false
        });
        return;
      }

      toast.error(
        "Ha ocurrido un error inesperado. Revisar más información en la consola",
        {
          position: POSITION.BOTTOM_CENTER,
          timeout: 2500,
          pauseOnFocusLoss: false,
          pauseOnHover: false,
          hideProgressBar: true,
          closeButton: false,
          icon: false
        }
      );
    });
});
</script>

<style scoped>
#login {
  min-height: 100%;
  background-color: #818080;
  background-image:
    linear-gradient(rgba(0, 0, 0, 0.18), rgba(0, 0, 0, 0.18)),
    url("/images/oficinaSPM.png");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  overflow: hidden;
}

.login-brand {
  position: absolute;
  top: 34px;
  left: 34px;
  z-index: 2;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  background: transparent;
}

.login-logo {
  display: block;
  width: auto;
  height: auto;
  max-width: 390px;
  max-height: 145px;
  object-fit: contain;
  filter: drop-shadow(0 3px 5px rgba(0, 0, 0, 0.35));
}

.login-card {
  position: relative;
  z-index: 2;
  backdrop-filter: blur(3px);
  box-shadow: 0 8px 28px rgba(0, 0, 0, 0.28);
}

@media (max-width: 900px) {
  #login {
    padding-top: 115px;
  }

  .login-brand {
    top: 18px;
    left: 50%;
    transform: translateX(-50%);
    width: min(84vw, 370px);
  }

  .login-logo {
    max-width: 100%;
    max-height: 95px;
  }
}
</style>
