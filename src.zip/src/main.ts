import { createApp } from 'vue';
import App from './App.vue';
import { registerPlugins } from '@/plugins';
import { createHead } from '@unhead/vue/client';
import router from '@/plugins/router';
import Toast from "vue-toastification";
import "vue-toastification/dist/index.css";
import { TAB_SITE_TITLE } from './config/env.config.js';


function applySpmBrowserIcon(): void {
    const iconPath = `/images/spmicono.png?v=${Date.now()}`;

    document
        .querySelectorAll<HTMLLinkElement>(
            'link[rel="icon"], link[rel="shortcut icon"], link[rel="apple-touch-icon"]'
        )
        .forEach((link) => link.remove());

    const favicon = document.createElement('link');
    favicon.rel = 'icon';
    favicon.type = 'image/png';
    favicon.href = iconPath;
    document.head.appendChild(favicon);

    const shortcutIcon = document.createElement('link');
    shortcutIcon.rel = 'shortcut icon';
    shortcutIcon.type = 'image/png';
    shortcutIcon.href = iconPath;
    document.head.appendChild(shortcutIcon);

    const appleTouchIcon = document.createElement('link');
    appleTouchIcon.rel = 'apple-touch-icon';
    appleTouchIcon.href = iconPath;
    document.head.appendChild(appleTouchIcon);
}

applySpmBrowserIcon();

const app = createApp(App);
const head = createHead({
    init:[
        {
            titleTemplate: `%s - ${TAB_SITE_TITLE}`,
            htmlAttrs: {lang: "es-MX"},

        },
    ]
});


registerPlugins(app);
app.use(head);
app.use(router);
app.use(Toast);
app.mount('#app');
